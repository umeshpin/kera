function addfun(addbt)
{
if (addfun.count == undefined)
	{
		addfun.count = 0;
	}
	else
	{
		addfun.count++;
	}
var addiv= document.createElement('div');
adbx="addbox"+addfun.count;
addiv.id = adbx;
addiv.className = "abox";
document.getElementById(device).appendChild(addiv);
if(addbt=="mn4")
adstr="<img src='SVG/protien.jpg' id='pro'/>";
else if(addbt=="mn5")
adstr="<img src='SVG/molecule.jpg' id='mol'/>";
else
adstr="<img src='SVG/degradation.jpg' id='degradation'/>";
document.getElementById(adbx).innerHTML=adstr;
 
  jsPlumb.ready(function () {ainstance.draggable($("#"+adbx),{ containment: "#device" }); });                                                       
         var ptxt = document.createElement("input");
        ptxt.setAttribute("type","text");
        ptxt.setAttribute("maxlength","7");
        ptxt.setAttribute("size","3");
        var pnm="pname"+addfun.count;
        ptxt.id=pnm;
        ptxt.value="name";
        ptxt.className ="name4";
        document.getElementById(adbx).appendChild(ptxt);
        document.getElementById(pnm).onmouseover =function(){ if(this.value=="name")  this.value="";this.focus();}
        document.getElementById(pnm).onmouseout =function(){ if(this.value=="")  this.value="name";}
        document.getElementById(pnm).onblur =function(){ if(this.value=="")  this.value="name";}

$(function(){   
    $.contextMenu({
        selector: '#'+adbx, 
        callback: function(key, options) {

                       epid=$(this).attr('id');
                       pmepidn=epid.substring(6,8);
                   if(key == "delete")
                   {
                      t=$(this).attr('id'); 
                      el=document.getElementById(t);
                      el.setAttribute("data-tep","") ;  
                      el.setAttribute("data-bep","") ;              
                      ainstance.deleteEndpoint(atep[pmepidn]);
                      ainstance.deleteEndpoint(rtep[pmepidn]);
                      ainstance.deleteEndpoint(abep[pmepidn]);
                      ainstance.deleteEndpoint(rbep[pmepidn]);
                      $( '#'+t ).remove();
                      atep[pmepidn]=undefined;
                      rtep[pmepidn]=undefined;
                      abep[pmepidn]=undefined;
                      rbep[pmepidn]=undefined;
                   } 
                    if(key == "delp")
                   {
                      t=$(this).attr('id');
                      el=document.getElementById(t);
                      el.setAttribute("data-tep","") ;  
                      el.setAttribute("data-bep","") ;
                      ainstance.deleteEndpoint(atep[pmepidn]);
                      ainstance.deleteEndpoint(rtep[pmepidn]);
                      ainstance.deleteEndpoint(abep[pmepidn]);
                      ainstance.deleteEndpoint(rbep[pmepidn]);
                      atep[pmepidn]=undefined;
                      rtep[pmepidn]=undefined;
                      abep[pmepidn]=undefined;
                      rbep[pmepidn]=undefined;
                   
                   } 
                  else if(key == "ren")  
                   {
                       nt=$(this).attr('id');
                       tn=nt.substring(6,8);
                       ts="pname"+tn;               
                       document.getElementById(ts).value=""; 
                       document.getElementById(ts).focus();
                    }   
                     else if(key == "atop")
                   {
                      if(atep[pmepidn]!=undefined || rtep[pmepidn]!=undefined)    
                                    alert("End point exists");
                      else
                      { 
                   
                 var aid=$(this).attr('id');
                 el=document.getElementById(aid);
                 el.setAttribute("data-tep","act") ;
               jsPlumb.ready(function () {
             var connectorPaintStyle = {lineWidth: 1, strokeStyle: "#000000", joinstyle: "round", outlineColor: "white", outlineWidth: 2  };
     var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF", fillStyle: "#dcd5d5", radius: 7, lineWidth: 3},
            isSource: true,isTarget: true,parameters:{ "pmatsrc":epid },connector: [ "Flowchart", { stub: [50, 50], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
            connectorStyle: connectorPaintStyle,connectorOverlays: [ [ "Arrow", { location: 1} ]   ]   };
      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything();
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }  atep[pmepidn]=ainstance.addEndpoint(aid,{anchor:[.49, 0, 0, -1,0,-10]},anEndpointSource);         
                    ainstance.fixEndpoints(aid); 
     }); }   }
                    else if(key == "abot")
                 {
                      if(abep[pmepidn]!=undefined || rbep[pmepidn]!=undefined)  
                            alert("End point exists");
                     else            
                      { 
                 var aid=$(this).attr('id');
                 el=document.getElementById(aid);
                 el.setAttribute("data-bep","act") ;
               jsPlumb.ready(function () {
             var connectorPaintStyle = {lineWidth: 1,strokeStyle: "#000000",joinstyle: "round",outlineColor: "white",outlineWidth: 2  };
     var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 7,lineWidth: 3},
            isSource: true,isTarget: true,parameters:{ "pmabsrc":epid },connector: [ "Flowchart", { stub: [50, 50], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
            connectorStyle: connectorPaintStyle,connectorOverlays: [ [ "Arrow", { location: 1} ]   ]   };
      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything();
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }
        abep[pmepidn]=ainstance.addEndpoint(aid,{anchor:[.5, 1, 0, 1,-10]},anEndpointSource);
                ainstance.fixEndpoints(aid);                                 
     });
    }
     }
  else if(key == "rtop")
              {
                      if(rtep[pmepidn]!=undefined || atep[pmepidn]!=undefined)     
                                    alert("End point exists");       
                        else
               { 
                 var rid=$(this).attr('id');
                 el=document.getElementById(rid);
                 el.setAttribute("data-tep","rep") ;
               jsPlumb.ready(function () {
           var connectorPaintStyle = { lineWidth: 1,strokeStyle: "#000000",joinstyle: "round",outlineColor: "white",outlineWidth: 2 };
          var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 7,lineWidth: 3},
                 isSource: true,isTarget: true,parameters:{ "pmrtsrc":epid },connector: [ "Flowchart", { stub: [50, 50], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
                                                  connectorStyle: connectorPaintStyle,connectorOverlays: [   [ "Arrow", { location: 1,width: 18, length: .05} ] ]};
      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything();
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }
                  rtep[pmepidn]=ainstance.addEndpoint(rid,{anchor:[.5, 0, 0, -1,0,-10]},anEndpointSource);
                  ainstance.fixEndpoints(rid); 
     });    } 
   }
      else if(key == "rbot")
                   {
                   if(rbep[pmepidn]!=undefined || abep[pmepidn]!=undefined)      
                         alert("End point exists");      
               else
                {  var rid=$(this).attr('id');
                    el=document.getElementById(rid);
                 el.setAttribute("data-bep","rep") ;
                   jsPlumb.ready(function () { 
          var connectorPaintStyle = { lineWidth: 1,strokeStyle: "#000000",joinstyle: "round",outlineColor: "white",outlineWidth: 2 };
          var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 7,lineWidth: 3},
                 isSource: true,isTarget: true,parameters:{ "pmrbsrc":epid },connector: [ "Flowchart", { stub: [50, 50], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
                                                  connectorStyle: connectorPaintStyle,connectorOverlays: [   [ "Arrow", { location: 1,width: 18, length: .05} ] ]};
            function fixEndpoints(parentnode) 
           { var endpoints = ainstance.getEndpoints(parentnode);
              var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource;});
              var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget; });
              calculateEndpoint(inputAr, true);
              calculateEndpoint(outputAr, false);
              ainstance.repaintEverything();
           }
           function calculateEndpoint(endpointArray, isInput) 
          {
            var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                                } 
                else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                       }       }    
            }    
                 rbep[pmepidn]=ainstance.addEndpoint(rid,{anchor:[.49, 1, 0, 1,-10]},anEndpointSource);
                ainstance.fixEndpoints(rid);
                    });           }
        }                                       
        },
        items: { 
            "delete": {name: "Remove", icon: "rmv"},  
                "ren": {name: "Rename", icon: "ren"},    
                     "act": {name: "Activation", icon: "act",
                     "items": {
                    "atop": {"name": "Top", icon: "top"},
                    "abot": {"name": "Bottom", icon: "bot"},         
                               }
                      },
                "rep": {name: "Repression", icon: "rep",
                    "items": {
                    "rtop": {"name": "Top", icon: "top"},
                    "rbot": {"name": "Bottom", icon: "bot"},         
                               }
                      },
             "delp": {name: "Delete End Points", icon: "del"}
           }
    });    
 });  
}
 