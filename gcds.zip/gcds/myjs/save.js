$(document).ready(function() {
    $('#mn2').click(function() { 
   //    alert("Updating");
var cs=[];
var ct=[];
var sax=[];
var dcs=[];
var dct=[];
var say=[];
var tax=[];
var tay=[];  
     jsPlumb.ready(function () {
     ep = ainstance.getConnections();
     for(i=0; i<ep.length; i++) 
        {
            ct[i] = ep[i].targetId;
            cs[i] = ep[i].sourceId;
            sax[i]=ep[i].endpoints[0].anchor.x;
            say[i]=ep[i].endpoints[0].anchor.y;
            tax[i]=ep[i].endpoints[1].anchor.x;
            tay[i]=ep[i].endpoints[1].anchor.y;
          }
         });     
var txml=["","","","","","","","","","","","","","","","","","","","","","",""];
var t=0;
var x=[];
var y=[];
var p,q,tx,ty;
var i=0;
 var svgs = $("#device").find('path');
 svgs.each(function () {
 xml = (new XMLSerializer()).serializeToString(this); 
 //alert(xml);
 cchar=xml.charAt(1);
 if(cchar=="p")
    ;
 else
 {
 if(i==0 || i==3 ||i==6 ||i==9 ||i==12 ||i==15 || i==18 || i==21 ||i==24 ||i==27 ||i==30 ||i==33 || i==36 || i==39 ||i==42 ||i==45 ||i==48 ||i==51 || i==54 ||i==57 ||i==60 || i==63)
 {
  var s= xml.indexOf( "d=" )+3;
  var e= xml.indexOf( "pointer-events=" )-2;
  txml[t]=xml.slice(s,e);
 }
 else if(i==2 || i==5 ||i==8 ||i==11 ||i==14 ||i==17 || i==20 || i==23 ||i==26 ||i==29 ||i==32 ||i==35 || i==38 || i==41 ||i==44 ||i==47 ||i==50 ||i==53 || i==56 ||i==59 ||i==62 || i==65)
 {
  var s= xml.indexOf( "d=" )+3; 
  var e= xml.indexOf( "class=" )-2;
  txml[t]=txml[t]+xml.slice(s,e);
  p=txml[t].indexOf( "." );
  x[t]=txml[t].slice(2,p);
  q=txml[t].indexOf( ",");
  ty=txml[t].slice(q+1,q+4);
  if(ty.charAt(2)==".")
   y[t]=ty.slice(0,-1);
  else
   y[t]=ty;
  t++;}  i++;
 }
 }); 
       $("#device").css({"border-radius":"0em"});
            html2canvas($("#device"), {
            onrendered: function(canvas) {
             var ctx = canvas.getContext("2d");
             ctx.strokeStyle = '#000';
             ctx.lineWidth = 1.5;
             ctx.fillStyle = '#000';
             for(k=0;k<t;k++)
             {
              ctx.save(); 
              src=cs[k].substring(0,3);  
              tgt=ct[k].substring(0,3);      
              if(src=="add" && tgt=="add")
              {
               sele=document.getElementById(cs[k]);
               tele=document.getElementById(ct[k]);
               spx=sele.offsetLeft;  
               spy=sele.offsetTop;
               tpx=tele.offsetLeft;  
               tpy=tele.offsetTop;
               var p=new Path2D(txml[k]); 
             
                   
                   if(spx<=tpx && spy<=tpy)
                   { 
                     dy=tpy-spy; 
                     if(cs[k]==ct[k])
                       ctx.translate(spx-77,spy-103);

                     else if(say[k]==0 && tay[k]==0)
                       ctx.translate(spx-77,spy-97);
                     else if(say[k]==1 && tay[k]==1)
                       ctx.translate(spx-77,spy-40);
                     else if(say[k]==0 && tay[k]==1)
                       ctx.translate(spx-77,spy-103);
                     else if(say[k]==1 && tay[k]==0)
                     { 
                       if(dy>75)
                          ctx.translate(spx-77,spy-40);
                       else
                       {
                         for(i=75,j=41;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(spx-77,spy-j);break;}
                          }  
                       }
                     }
                    
                   }
                 else if(spx>=tpx && spy>=tpy)
                  { 
                    dy=spy-tpy;  
                      if(say[k]==1 && tay[k]==1)
                         ctx.translate(tpx-77,tpy-30);
                      else if(say[k]==0 && tay[k]==0)
                         ctx.translate(tpx-77,tpy-104);
                      else if(say[k]==1 && tay[k]==0)
                         ctx.translate(tpx-77,tpy-97);
                      else if(say[k]==0 && tay[k]==1)
                      {
                        if(dy>65)
                            ctx.translate(tpx-77,tpy-40);
                        else 
                        { for(i=65,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(tpx-77,tpy-j);break;}
                          }
                        }  
                      }    
                  }
             
                  else if(spx<=tpx && spy>=tpy)
                  {  
                    dy=spy-tpy;  
                    if(say[k]==0 && tay[k]==0)
                          ctx.translate(spx-79,tpy-97); 
                    else if(say[k]==1 && tay[k]==1)
                          ctx.translate(spx-79,tpy-30); 
                    else  if(say[k]==0 && tay[k]==1)
                      {  
                        if(dy>65)
                            ctx.translate(spx-79,tpy-30); 
                        else 
                        { for(i=65,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(spx-79,tpy-j);break;}
                          }
                        }  
                      }
                    else  if(say[k]==1 && tay[k]==0)
                            ctx.translate(spx-79,tpy-97);
                  }
                  else if(spx>=tpx && spy<=tpy)
                  { 
                     dy=tpy-spy; 
                   if(say[k]==1 && tay[k]==1)
                     ctx.translate(tpx-77,spy-40);    
                   else if(say[k]==0 && tay[k]==0)
                     ctx.translate(tpx-77,spy-97);
                   else if(say[k]==0 && tay[k]==1)
                     ctx.translate(tpx-77,spy-97);    
                   else if(say[k]==1 && tay[k]==0)
                   { 
                      if(dy>75)
                          ctx.translate(tpx-77,spy-40);
                      else
                      {
                        for(i=75,j=41;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(tpx-77,spy-j);break;}
                          }  
                      }
                   }
                  }
               ctx.stroke(p);   
               ctx.fill(p); 
               ctx.restore();
              }
             } 
             
      /*       for(k=0;k<t;k++)
             {
              ctx.save(); 
              src=cs[k].substring(0,3);  
              tgt=ct[k].substring(0,3);      
              if(src=="ddi" && tgt=="ddi")
              {
               sele=document.getElementById(cs[k]);
               tele=document.getElementById(ct[k]);
               spx=sele.offsetLeft;  
               spy=sele.offsetTop;
               tpx=tele.offsetLeft;  
               tpy=tele.offsetTop;
               var p=new Path2D(txml[k]); 
                    
                   if(spx<=tpx && spy<=tpy)
                   { 
                     dy=tpy-spy; 
                     if(cs[k]==ct[k])
                       ctx.translate(spx-77,spy-103);
                     else if(say[k]==0 && tay[k]==0)
                       ctx.translate(spx-77,spy-97);
                     else if(say[k]==1 && tay[k]==1)
                       ctx.translate(spx-77,spy-40);
                     else if(say[k]==0 && tay[k]==1)
                       ctx.translate(spx-77,spy-103);
                     else if(say[k]==1 && tay[k]==0)
                     { 
                       if(dy>75)
                          ctx.translate(spx-77,spy-40);
                       else
                       {
                         for(i=75,j=41;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(spx-77,spy-j);break;}
                          }  
                       }
                     }
                    
                   }
                 else if(spx>=tpx && spy>=tpy)
                  { 
                    dy=spy-tpy;  
                      if(say[k]==1 && tay[k]==1)
                         ctx.translate(tpx-77,tpy-30);
                      else if(say[k]==0 && tay[k]==0)
                         ctx.translate(tpx-77,tpy-104);
                      else if(say[k]==1 && tay[k]==0)
                         ctx.translate(tpx-77,tpy-97);
                      else if(say[k]==0 && tay[k]==1)
                      {
                        if(dy>65)
                            ctx.translate(tpx-77,tpy-40);
                        else 
                        { for(i=65,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(tpx-77,tpy-j);break;}
                          }
                        }  
                      }    
                  }
             
                  else if(spx<=tpx && spy>=tpy)
                  {  
                    dy=spy-tpy;  
                    if(say[k]==0 && tay[k]==0)
                          ctx.translate(spx-79,tpy-97); 
                    else if(say[k]==1 && tay[k]==1)
                          ctx.translate(spx-79,tpy-30); 
                    else  if(say[k]==0 && tay[k]==1)
                      {  
                        if(dy>65)
                            ctx.translate(spx-79,tpy-30); 
                        else 
                        { for(i=65,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(spx-79,tpy-j);break;}
                          }
                        }  
                      }
                    else  if(say[k]==1 && tay[k]==0)
                            ctx.translate(spx-79,tpy-97);
                  }
                  else if(spx>=tpx && spy<=tpy)
                  { 
                     dy=tpy-spy; 
                   if(say[k]==1 && tay[k]==1)
                     ctx.translate(tpx-77,spy-40);    
                   else if(say[k]==0 && tay[k]==0)
                     ctx.translate(tpx-77,spy-97);
                   else if(say[k]==0 && tay[k]==1)
                     ctx.translate(tpx-77,spy-97);    
                   else if(say[k]==1 && tay[k]==0)
                   { 
                      if(dy>75)
                          ctx.translate(tpx-77,spy-40);
                      else
                      {
                        for(i=75,j=41;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(tpx-77,spy-j);break;}
                          }  
                      }
                   }
                  }
               ctx.stroke(p);   
               ctx.fill(p); 
               ctx.restore();
              }
             } 
             */          
             for(k=0;k<t;k++)
             {   
              ctx.save(); 
              src=cs[k].substring(0,3);  
              tgt=ct[k].substring(0,3);  
              isax=sax[k]*1000000;  
              itax=tax[k]*1000000;  
              if(src=="con" && tgt=="con")
              {
               sele=document.getElementById(cs[k]);
               tele=document.getElementById(ct[k]);
               spx=sele.offsetLeft;  
               spy=sele.offsetTop;
               tpx=tele.offsetLeft;  
               tpy=tele.offsetTop;
               if(isax<0)  aisax=-(isax); else aisax=isax;
               if(itax<0)  aitax=-(itax); else aitax=itax;
               aspx=spx+aisax;
               atpx=tpx+aitax;
               var p=new Path2D(txml[k]);
                   if(cs[k]==ct[k])
                   {
                        if(isax>0 && itax>0)
                        { 
                          if(isax<itax)
			    ctx.translate((spx+isax)-77,spy-40);
                          else
                            ctx.translate((tpx+itax)-77,tpy-40);
                        }
                        else if(isax<0 && itax<0)
                        { 
                          if(isax<itax) 
			    ctx.translate((tpx-itax)-77,tpy+30);
                          else
                            ctx.translate((spx-isax)-77,spy+30);
                        }
                        else if(isax<0 && itax>0)
                        {
                          if(-isax<itax) 
                            ctx.translate((spx-isax)-77,spy-50);
                          else if(-isax>itax) 
                            ctx.translate((tpx+itax)-77,tpy-50);
                          else
                            ctx.translate((spx-isax)-77,spy-50);
                        } 
                        else if(isax>0 && itax<0)
                        {
                          if(isax<-itax) 
                            ctx.translate((spx+isax)-77,spy-50);
                          else if(isax>-itax) 
                            ctx.translate((tpx-itax)-77,tpy-50);
                          else
                            ctx.translate((spx+isax)-77,spy-50);
                        }    
                   } 
                  else if(spy==tpy)
                     { 
                        if(aspx>=atpx)
                        { 
                          if (itax>0 && isax<0)
                          {
                             ctx.translate((tpx+itax)-77,spy-50);
                          }
                          else if(itax<0 && isax>0)
                          {  itax=-(itax);ctx.translate((tpx+itax)-77,spy-50);}
                        }
                        else  
                        {
                          if (itax>0 && isax<0)
                          {
                             isax=-(isax);ctx.translate((spx+isax)-77,spy-50);
                          }
                          else if(itax<0 && isax>0)
                             ctx.translate((spx+isax)-77,spy-50);   
                        }
                     }  
     
                   else if(aspx<atpx && spy<tpy)
                   {   
                     dy=tpy-spy; 
                     if(itax>0 && isax>0)
                       ctx.translate((spx+isax)-77,spy-40);
                     else if(itax>0 && isax<0)
                     {
                       if(dy>84)
                        {isax=-(isax);ctx.translate((spx+isax)-77,spy+30);}
                        else
                        {
                         for(i=84,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            { isax=-(isax);ctx.translate((spx+isax)-77,(spy+i)-55);break;}
                          }  
                       }
                     }
                     else if(itax<0 && isax<0)
                       {isax=-(isax);ctx.translate((spx+isax)-77,spy+30);}
                     else if(itax<0 && isax>0)
                       ctx.translate((spx+isax)-77,spy-50); 

                   }  
                  else if(aspx>=atpx && spy>=tpy)
                  {
                     dy=spy-tpy;
                     if(itax>0 && isax>0)
                       ctx.translate((tpx+itax)-77,tpy-40);
                     else if(itax>0 && isax<0)
                       ctx.translate((tpx+itax)-77,tpy-50); 
                     else if(itax<0 && isax<0)
                       {itax=-(itax);ctx.translate((tpx+itax)-77,tpy+30);}
                     else if(itax<0 && isax>0)
                     {
                       if(dy>84)
                       { itax=-(itax);ctx.translate((tpx+itax)-77,tpy+30); }
                       else
                       {
                         for(i=84,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            { itax=-(itax);ctx.translate((tpx+itax)-77,(tpy+i)-55);break;}
                          }  
                       }
                     }
                  }
                   
                  else if(aspx>=atpx && spy<=tpy)
                  { 
                    dy=tpy-spy;    
                    if(itax>0 && isax>0)
                       ctx.translate((tpx+itax)-77,spy-40);
                     else if(itax>0 && isax<0)
                      { 
                         if(dy>84)
                         { ctx.translate((tpx+itax)-77,spy+30); }
                         else
                         {
                           for(i=84,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            { ctx.translate((tpx+itax)-77,(spy+i)-55);break;}
                           }  
                         }
                      }
                     else if(itax<0 && isax<0)
                       {itax=-(itax);ctx.translate((tpx+itax)-77,spy+30);}
                     else if(itax<0 && isax>0)
                       {itax=-(itax);ctx.translate((tpx+itax)-77,spy-50); }
                  }
                  else if(aspx<=atpx && spy>=tpy)
                  { dy=spy-tpy;                      
                     if(itax>0 && isax>0)
                       ctx.translate((spx+isax)-77,tpy-40);
                     else if(itax>0 && isax<0)
                       {isax=-(isax);ctx.translate((spx+isax)-77,tpy-50);}
                     else if(itax<0 && isax<0)
                       {isax=-(isax);ctx.translate((spx+isax)-77,tpy+30);}
                     else if(itax<0 && isax>0)
                     {
                        if(dy>84)
                        { ctx.translate((spx+isax)-77,tpy+30); }
                        else
                        {
                         for(i=84,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            { ctx.translate((spx+isax)-77,(tpy+i)-55);break;}
                          }  
                        }
                     }
                  } 
               ctx.stroke(p);   
               ctx.fill(p); 
               ctx.restore();
               }
             }         
              
              for(k=0;k<t;k++)
              {
              ctx.save(); 
              src=cs[k].substring(0,3);  
              tgt=ct[k].substring(0,3); 
              isax=sax[k]*1000000; 
              if(src=="con" && tgt=="add")
              {
               sele=document.getElementById(cs[k]);
               tele=document.getElementById(ct[k]);
               spx=sele.offsetLeft;  
               spy=sele.offsetTop;
               tpx=tele.offsetLeft;  
               tpy=tele.offsetTop;
               if(isax<0)  aisax=-(isax); else aisax=isax;
               aspx=aisax+spx;
               var p=new Path2D(txml[k]);
                if(aspx<=tpx && spy<=tpy)
                   { 
                     dy=tpy-spy;
                     if(isax>0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
                       ctx.translate((spx+isax)-77,spy-40);
                     else if(isax>0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                       ctx.translate((spx+isax)-77,spy-40);
                     else if(isax<0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
		     {
		       if(dy>120)
                           {isax=-(isax);ctx.translate((spx+isax)-77,spy+30);}
                       else
                       {
                        for(i=120,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {isax=-(isax);ctx.translate((spx+isax)-77,(spy-j)+60);}
                          }  
                       }                      

                     }
                     else if(isax<0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                       {isax=-(isax);ctx.translate((spx+isax)-77,spy+30);}                   
                   }
                  else if(aspx>=tpx && spy>=tpy)
                  {
                      if(isax>0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
                       ctx.translate(tpx-60,tpy-85);
                    else if(isax>0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                       ctx.translate(tpx-60,tpy-15);
                    else if(isax<0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
                       ctx.translate(tpx-60,tpy-85);
                    else if(isax<0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                       ctx.translate(tpx-60,tpy-15);
                  }
                  else if(aspx>=tpx && spy<=tpy)
                  { 
                      if(isax>0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
                       ctx.translate(tpx-60,spy-50);  
                    else if(isax>0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                       ctx.translate(tpx-60,spy-50);
                    else if(isax<0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
                    {  
                       dy=tpy-spy;
                       if(dy>110)
                          ctx.translate(tpx-60,spy+30);
                       else
                       {
                        for(i=110,j=31;i>=0;i--,j++)
                          { 
                            if(i==dy)        
                            {  ctx.translate(tpx-60,(spy-j)+50);break;}
                          }  
                       }
                    }
                    else if(isax<0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                       ctx.translate(tpx-60,spy+30);
                  }
                  else if(aspx<=tpx && spy>=tpy)
                  {
                    dy=spy-tpy;
                    if(isax>0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
                      ctx.translate((spx+isax)-77,tpy-77);
                    else if(isax>0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                    {      if(dy>40)
                            { ctx.translate((spx+isax)-77,tpy-10);}
                             else
                             {
                                  for(i=40,j=10;i>=0;i--,j++)
                                 { 
                                   if(i==dy)        
                                   {  ctx.translate((spx+isax)-77,(tpy-j));}
                                 }  
                             }
                    }
                    else if(isax<0 && ((tax[k]==.5 && tay[k]==0) || (tax[k]==.49 && tay[k]==0 )))
                        {isax=-(isax);ctx.translate((spx+isax)-77,tpy-97);}
                   else if(isax<0 && ((tax[k]==.5 && tay[k]==1) || (tax[k]==.49 && tay[k]==1 )))
                        {isax=-(isax);ctx.translate((spx+isax)-77,tpy-10);}
                  } 
               ctx.stroke(p);   
               ctx.fill(p); 
               ctx.restore();
              }
             }
              
             for(k=0;k<t;k++)
             {
              ctx.save(); 
              src=cs[k].substring(0,3);  
              tgt=ct[k].substring(0,3);  
              itax=tax[k]*1000000; 
              if(src=="add" && tgt=="con")
              {
               sele=document.getElementById(cs[k]);
               tele=document.getElementById(ct[k]);
               spx=sele.offsetLeft;  
               spy=sele.offsetTop;
               tpx=tele.offsetLeft;  
               tpy=tele.offsetTop;
               if(itax<0)  aitax=-(itax); else aitax=itax;
               atpx=aitax+tpx;
               var p=new Path2D(txml[k]);
                if(spx<=atpx && spy<=tpy)
                   { 
                     if(itax>0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                       ctx.translate(spx-77,spy-97);
                     else  if(itax>0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                       ctx.translate(spx-77,spy-40);
                     else if(itax<0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                       ctx.translate(spx-77,spy-104);
                     else if(itax<0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                       ctx.translate(spx-77,spy-40);                 
                   }
                  else if(spx>=atpx && spy>=tpy)
                  {
                     dy=spy-tpy;
                     if(itax>0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                       ctx.translate((tpx+itax)-97,tpy-77);
                     else  if(itax>0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                       ctx.translate((tpx+itax)-97,tpy-60);   
                     else if(itax<0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                     {
                       if(dy>120)
                        {itax=-(itax);ctx.translate((tpx+itax)-97,tpy+10);}
                        else
                        {
                              for(i=120,j=11;i>=0;i--,j++)
                              { 
                                 if(i==dy)        
                                  {  itax=-(itax);ctx.translate((tpx+itax)-97,(tpy-j)+20);}
                              }  
                        } 
                     }
                     else if(itax<0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                       {itax=-(itax);ctx.translate((tpx+itax)-97,tpy+10);}
                  }
                   
                  else if(spx>=atpx && spy<=tpy)
                  { 
                     dy=tpy-spy;
                     if(itax>0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                       ctx.translate((tpx+itax)-97,spy-103);
                     else  if(itax>0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                     { 
                       if(dy>41)
                        { ctx.translate((tpx+itax)-97,spy-30);}
                       else
                         {
                              for(i=41,j=31;i>=0;i--,j++)
                              { 
                                 if(i==dy)        
                                  {  ctx.translate((tpx+itax)-97,(spy-j));}
                              }  
                         } 
                     }
                     else if(itax<0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                       {itax=-(itax);ctx.translate((tpx+itax)-97,spy-103);}
                     else if(itax<0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                      {itax=-(itax);ctx.translate((tpx+itax)-97,spy-40);}
                  }
                  else if(spx<=atpx && spy>=tpy)
                  {  
                     dy=spy-tpy;
                     if(itax>0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                       ctx.translate(spx-77,tpy-77);
                     else if(itax>0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                       ctx.translate(spx-77,tpy-77);
                     else if(itax<0 && ((sax[k]==.5 && say[k]==0) || (sax[k]==.49 && say[k]==0 )))
                     {  
                        if(dy>119)
                          ctx.translate(spx-77,tpy+10);
                          else
                         {
                              for(i=119,j=11;i>=0;i--,j++)
                              { 
                                 if(i==dy)        
                                  {  ctx.translate(spx-77,(tpy-j)+20);}
                              }  
                         } 
                     }
                     else if(itax<0 && ((sax[k]==.5 && say[k]==1) || (sax[k]==.49 && say[k]==1 )))
                      ctx.translate(spx-77,tpy+10);
                  } 
               ctx.stroke(p);   
               ctx.fill(p); 
               ctx.restore();
              }   
             }
            var img = canvas.toDataURL("image/png");
            window.open(img);
            $("#device").css({"border-radius":"0.5em"}); }
        });  
    }); 
});
