/* 
save is to be done seperate for ddiv
*/
$(function(e){
    $.contextMenu({   
        selector: '#device', 
        callback: function(key, options) {    
                       
	if(key == "cls")
                {
                   location.reload();
                   return ;
                }
               else if(key == "act")
                  {    
	        ddivc++;
                        ddivn++;
                        var ddiv = document.createElement('div');
	        ddivid="ddiv"+ddivc;
    	        ddiv.id=ddivid;
                        ddiv.className = "tddivcn";            
                        ddiv.style.position = "absolute";
                        ddiv.style.left = divmX-365+'px';
                        ddiv.style.top = divmY-95+'px'; 
	        document.getElementById(device).appendChild(ddiv); 
	        jsPlumb.ready(function () {ainstance.draggable($("#"+ddivid),{ containment: "#device" }); });            
               jsPlumb.ready(function () {

             var connectorPaintStyle = {lineWidth: 1,strokeStyle: "#000001",joinstyle: "round",outlineColor: "white",outlineWidth: 2  };
     var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 6,lineWidth: 2},
            isSource: true,isTarget: true,connector: [ "Flowchart", { stub: [40, 40], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
            connectorStyle: connectorPaintStyle,connectorOverlays: [ [ "Arrow", { location: 1} ]   ]   };

      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything(); 
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }
        ainstance.addEndpoint(ddivid,{anchor:[.5, 1, 0,1,-4,-20]},anEndpointSource);
                ainstance.fixEndpoints(ddivid);                                 
     });       
   }           

 else if(key == "rep")
     {	      
	        ddivc++;
                        ddivn++;
                        var ddiv = document.createElement('div');
	        ddivid="ddiv"+ddivc;
    	        ddiv.id=ddivid;
                        ddiv.className = "tddivcn";            
                        ddiv.style.position = "absolute";
                        ddiv.style.left = divmX-365+'px';
                        ddiv.style.top = divmY-95+'px'; 
	        document.getElementById(device).appendChild(ddiv);   
	        jsPlumb.ready(function () {ainstance.draggable($("#"+ddivid),{ containment: "#device" }); });                             
               jsPlumb.ready(function () {
              var connectorPaintStyle = { lineWidth: 1,strokeStyle: "#000001",joinstyle: "round",outlineColor: "white",outlineWidth: 2 };
          var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 6,lineWidth:2},
                 isSource: true,isTarget: true,connector: [ "Flowchart", { stub: [40, 40], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
                                                  connectorStyle: connectorPaintStyle,connectorOverlays: [   [ "Arrow", { location: 1} ] ]};
      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything();
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }
        ainstance.addEndpoint(ddivid,{anchor:[.5, 1, 0, 1,-4,-20]},anEndpointSource);
                ainstance.fixEndpoints(ddivid);                                 
     });
                       
}
    else if(key == "lab")
    {
                      
                        ldivc++;
                        var ldiv = document.createElement('div');
	        ldivid="ldiv"+ldivc;
    	        ldiv.id=ldivid;
                        ldiv.className = "ldivcn";            
                        ldiv.style.position = "absolute";
                        ldiv.style.left = divmX-365+'px';
                        ldiv.style.top = divmY-95+'px'; 
	        document.getElementById(device).appendChild(ldiv); 
                        jsPlumb.ready(function () {ainstance.draggable($("#"+ldivid),{ containment: "#device" }); });    
  txt = document.createElement("input");
        txt.setAttribute("type","text");
        txt.setAttribute("maxlength","10");
        txt.setAttribute("size","5");
        txt.setAttribute("value","name");
        nm="name"+myfunction.count;
        txt.id=nm; 
                        txt.className ="name9";
        document.getElementById(ldivid).appendChild(txt);
        document.getElementById(nm).onmouseover =function(){ if(this.value=="name")  this.value="";this.focus();}
        document.getElementById(nm).onmouseout =function(){ if(this.value=="")  this.value="name";}
        document.getElementById(nm).onblur =function(){ if(this.value=="")  this.value="name";}
    }
 else if(key == "tep")
    {
              ddivc++;
                        ddivn++;
                        var ddiv = document.createElement('div');
	        ddivid="ddiv"+ddivc;
    	        ddiv.id=ddivid;
                        ddiv.className = "tddivcn";            
                        ddiv.style.position = "absolute";
                        ddiv.style.left = divmX-365+'px';
                        ddiv.style.top = divmY-95+'px'; 
	        document.getElementById(device).appendChild(ddiv);   
	        jsPlumb.ready(function () {ainstance.draggable($("#"+ddivid),{ containment: "#device" }); });                             
               jsPlumb.ready(function () {
              var connectorPaintStyle = { lineWidth: 1,strokeStyle: "#000001",joinstyle: "round",outlineColor: "white",outlineWidth: 2 };
          var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 6,lineWidth:2},
                 isSource: true,isTarget: true,connector: [ "Flowchart", { stub: [40, 40], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
                                                  connectorStyle: connectorPaintStyle,connectorOverlays: [   [ "Arrow", { location: 1} ] ]};
      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything();
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }
        ainstance.addEndpoint(ddivid,{anchor:[.5, 1, 0, -1,-4,-20]},anEndpointSource);
                ainstance.fixEndpoints(ddivid);                                 
     });
    }

        },
        items: { 
            "cls": {name: "Clear ALL", icon: "clr"},
            "act": {name: "Activation", icon: "act"},
            "rep": {name: "Repression", icon: "rep"},
            "lab": {name: "New Label", icon: "ren"},
            "tep": {name: "Target EP", icon: "tar"}
                  }
    });    
    });  

  
