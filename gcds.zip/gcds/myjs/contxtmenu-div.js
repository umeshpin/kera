$(function(){
    $.contextMenu({
        selector: '#container1', 
        callback: function(key, options) {              
                    if(key == "clear")
                   {                      
                     $( "#container1" ).empty();
                     for(i=0;i<21;i++)
                     {
                     ainstance.deleteEndpoint(con1aep[i]);
                     ainstance.deleteEndpoint(con1rep[i]); 
                     }
                     con1ecp=0;
                     for(i=0;i<pcountd1;i++)
                          c1pos[i]=undefined;
                     pcountd1=0;  
if(c1w==820) l=12;else if(c1w==325) l=1;else if(c1w==370) l=2;else if(c1w==415) l=3;else if(c1w==460) l=4;else if(c1w==505)
l=5;else if(c1w==550) l=6;else if(c1w==595) l=7;else if(c1w==640) l=8;else if(c1w==685) l=9;else if(c1w==730) l=10;
else if(c1w==775) l=11;else l=0;
                     var alin1 = document.createElement('div');
                     al1="align1";
                     alin1.id=al1;
                     alin1.className = "align";
                     document.getElementById("container1").appendChild(alin1);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align1").innerHTML=astr; 
	     for(i=0,w=280;i<l;i++,w+=45)
                     { 
                       var c1alinp = document.createElement('div');
                       var al1="alp1"+(w+45);
                       c1alinp.id=al1;
                       c1alinp.className = "alignp";
                       document.getElementById("container1").appendChild(c1alinp);
                       $(document).ready(function(){$("#"+al1).css({"top":36,"left":w}); });   
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al1).innerHTML=astp;
                     } 
                    } 
                   else if(key == "dec")
                   {
                    var f=0;
                    if(c1w <= 280)
                      alert("Device 1 min width");
                    else
                      {
                       $('#container1 > div').map(function() {
                       els=this.id;
                       aels=els.substring(0,3);
                       if(aels == "box")
                       {
                        t=$('#'+els).position().left;
                        if(c1w<=325 && t>=253)
                          f=1;
                        else if(c1w<=370 && t>=298)
                          f=1;   
                        else  if(c1w<=415 && t>=343)
                          f=1;   
                        else if(c1w<=460 && t>=388)
                          f=1;   
                        else  if(c1w<=505 && t>=433)
                          f=1;  
	      else if(c1w<=550 && t>=478)
                          f=1;   
                        else  if(c1w<=595 && t>=523)
                          f=1;   
                        else if(c1w<=640 && t>=568)
                          f=1;   
                        else  if(c1w<=685 && t>=613)
                          f=1;  
	      else if(c1w<=730 && t>=658)
                          f=1;   
                        else  if(c1w<=775 && t>=703)
                          f=1;  
	      else  if(c1w<=820 && t>=748)
                          f=1; 
                       }  }); 
                      if(f==0)
                      {
                        $( '#alp1'+c1w).remove(); 
                        c1w-=45;
                        c1pa--;
                        $(document).ready(function(){$("#container1").css({"height":130,"width": c1w}); });
                      }
                      else
                         alert("Move parts to the Left axis");
                      } 
                   } 
                    else if(key == "win" && c1pa <18)
                    {
                      c1alpw=c1w;
                      c1w+=45;
                      if(c1w >= 865)
	      alert("Device 2 Max width");
                      else
                       {
                      c1pa++;
                      $(document).ready(function(){$("#container1").css({"height":130,"width": c1w}); }); 
                       var c1alinp = document.createElement('div');
                       var al1="alp1"+c1w;
                       c1alinp.id=al1;
                       c1alinp.className = "alignp";
                       document.getElementById("container1").appendChild(c1alinp);
                       $(document).ready(function(){$("#"+al1).css({"top":36,"left":c1alpw}); });                    
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al1).innerHTML=astp;                      
                       }
                    }                
        },
        items: { 
            "clear": {name: "Clear Device", icon: "clr"},
            "win": {name: "Width+", icon: "inc"},
            "dec": {name: "Width--", icon: "dec"}
                    }
    });    
    });  
$(function(){
    $.contextMenu({
        selector: '#container2', 
        callback: function(key, options) {    
                   if(key == "clear")
                   {
		     $( "#container2" ).empty();
                      for(i=0;i<21;i++)
                     {
                     ainstance.deleteEndpoint(con2aep[i]);
                     ainstance.deleteEndpoint(con2rep[i]);
                     }
                     con2ecp=0;
                      for(i=0;i<pcountd2;i++)
                          c2pos[i]=undefined;
                     pcountd2=0;
if(c2w==820) l=12;else if(c2w==325) l=1;else if(c2w==370) l=2;else if(c2w==415) l=3;else if(c2w==460) l=4;else if(c2w==505)
l=5;else if(c2w==550) l=6;else if(c2w==595) l=7;else if(c2w==640) l=8;else if(c2w==685) l=9;else if(c2w==730) l=10;
else if(c2w==775) l=11;else l=0;
                     var alin2 = document.createElement('div');
                     al1="align2";
                     alin2.id=al1;
                     alin2.className = "align";
                     document.getElementById("container2").appendChild(alin2);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align2").innerHTML=astr; 
	     for(i=0,w=280;i<l;i++,w+=45)
                     { 
                       var c2alinp = document.createElement('div');
                       var al2="alp2"+(w+45);
                       c2alinp.id=al2;
                       c2alinp.className = "alignp";
                       document.getElementById("container2").appendChild(c2alinp);
                       $(document).ready(function(){$("#"+al2).css({"top":36,"left":w}); });                    
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al2).innerHTML=astp;
                     }
                   }
                     else if(key == "dec")
                   {
                    var f=0;
                    if(c2w <= 280)
                      alert("Device 2 min width");
                    else
                      {
                       $('#container2 > div').map(function() {
                       els=this.id;
                       aels=els.substring(0,3);
                       if(aels == "box")
                       {
                        t=$('#'+els).position().left;
                        if(c2w<=325 && t>=253)
                          f=1;
                        else if(c2w<=370 && t>=298)
                          f=1;   
                        else  if(c2w<=415 && t>=343)
                          f=1;   
                        else if(c2w<=460 && t>=388)
                          f=1;   
                        else  if(c2w<=505 && t>=433)
                          f=1;  
	      else if(c2w<=550 && t>=478)
                          f=1;   
                        else  if(c2w<=595 && t>=523)
                          f=1;   
                        else if(c2w<=640 && t>=568)
                          f=1;   
                        else  if(c2w<=685 && t>=613)
                          f=1;  
	      else if(c2w<=730 && t>=658)
                          f=1;   
                        else  if(c2w<=775 && t>=703)
                          f=1;  
	      else  if(c2w<=820 && t>=748)
                          f=1; 
                       }  }); 
                      if(f==0)
                      {
                        $( '#alp2'+c2w).remove(); 
                        c2w-=45;
                        c2pa--;
                        $(document).ready(function(){$("#container2").css({"height":130,"width": c2w}); });
                      }
                      else
                         alert("Move parts to the Left axis");
                      } 
                   } 
	 else if(key == "win" && c2pa <18)
                    {
                      c2alpw=c2w;
                      c2w+=45;
                      if(c2w >= 865)
	        alert("Device 2 Max width");
                      else
                       {
                      c2pa++;
                      $(document).ready(function(){$("#container2").css({"height":130,"width": c2w}); }); 
                       var c2alinp = document.createElement('div');
                       var al2="alp2"+c2w;
                       c2alinp.id=al2;
                       c2alinp.className = "alignp";
                       document.getElementById("container2").appendChild(c2alinp);
                       $(document).ready(function(){$("#"+al2).css({"top":36,"left":c2alpw}); });                    
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al2).innerHTML=astp;                      
                       }
                    }       
        },
        items: { 
            "clear": {name: "Clear Device", icon: "clr"},
            "win": {name: "Width+", icon: "inc"},  
            "dec": {name: "Width--", icon: "dec"}    
                 }
    });    
    });  
$(function(){
    $.contextMenu({
        selector: '#container3', 
        callback: function(key, options) {    
                  if(key == "clear")
                   { 
		     $( "#container3" ).empty();              
                     for(i=0;i<21;i++)
                     {
                     ainstance.deleteEndpoint(con3aep[i]);
                     ainstance.deleteEndpoint(con3rep[i]);
                     }
                     con3ecp=0;
                      for(i=0;i<pcountd3;i++)
                          c3pos[i]=undefined;
                     pcountd3=0;
if(c3w==820) l=12;else if(c3w==325) l=1;else if(c3w==370) l=2;else if(c3w==415) l=3;else if(c3w==460) l=4;else if(c3w==505)
l=5;else if(c3w==550) l=6;else if(c3w==595) l=7;else if(c3w==640) l=8;else if(c3w==685) l=9;else if(c3w==730) l=10;
else if(c3w==775) l=11;else l=0;
                     var alin3 = document.createElement('div');
                     al1="align3";
                     alin3.id=al1;
                     alin3.className = "align";
                     document.getElementById("container3").appendChild(alin3);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align3").innerHTML=astr; 
		     for(i=0,w=280;i<l;i++,w+=45)
                     { 
                       var c3alinp = document.createElement('div');
                       var al3="alp3"+(w+45);
                       c3alinp.id=al3;
                       c3alinp.className = "alignp";
                       document.getElementById("container3").appendChild(c3alinp);
                       $(document).ready(function(){$("#"+al3).css({"top":36,"left":w}); });                    
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al3).innerHTML=astp;
                     }
                   }
                    else if(key == "dec")
                   {
                    var f=0;
                    if(c3w <= 280)
                      alert("Device 3 min width");
                    else
                      {
                       $('#container3 > div').map(function() {
                       els=this.id;
                       aels=els.substring(0,3);
                       if(aels == "box")
                       {
                        t=$('#'+els).position().left;
                        if(c3w<=325 && t>=253)
                          f=1;
                        else if(c3w<=370 && t>=298)
                          f=1;   
                        else  if(c3w<=415 && t>=343)
                          f=1;   
                        else if(c3w<=460 && t>=388)
                          f=1;   
                        else  if(c3w<=505 && t>=433)
                          f=1;  
	      else if(c3w<=550 && t>=478)
                          f=1;   
                        else  if(c3w<=595 && t>=523)
                          f=1;   
                        else if(c3w<=640 && t>=568)
                          f=1;   
                        else  if(c3w<=685 && t>=613)
                          f=1;  
	      else if(c3w<=730 && t>=658)
                          f=1;   
                        else  if(c3w<=775 && t>=703)
                          f=1;  
	      else  if(c3w<=820 && t>=748)
                          f=1; 
                       }  }); 
                      if(f==0)
                      {
                        $( '#alp3'+c3w).remove(); 
                        c3w-=45;
                        c3pa--;
                        $(document).ready(function(){$("#container3").css({"height":130,"width": c3w}); });
                      }
                      else
                         alert("Move parts to the Left axis");
                      } 
                   } 
                  
                else if(key == "win" && c3pa <18)
                    {
                      c3alpw=c3w;
                      c3w+=45;
                      if(c3w >= 865)
	      alert("Device 3 Max width");
                      else
                       {
                      c3pa++;
                      $(document).ready(function(){$("#container3").css({"height":130,"width": c3w}); }); 
                       var c3alinp = document.createElement('div');
                       var al3="alp3"+c3w;
                       c3alinp.id=al3;
                       c3alinp.className = "alignp";
                       document.getElementById("container3").appendChild(c3alinp);
                       $(document).ready(function(){$("#"+al3).css({"top":36,"left":c3alpw}); });                    
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al3).innerHTML=astp;                      
                       }
                    }                          
        },
        items: { 
            "clear": {name: "Clear Device", icon: "clr"},
            "win": {name: "Width+", icon: "inc"},
            "dec": {name: "Width--", icon: "dec"} 
                    }
    });    
    });  
$(function(){
    $.contextMenu({
        selector: '#container4', 
        callback: function(key, options) {   
               if(key == "clear")
                   {        
	   for(i=0;i<21;i++)
                     {
		      $( "#container4" ).empty();
                     ainstance.deleteEndpoint(con4aep[i]);
                     ainstance.deleteEndpoint(con4rep[i]);
                     }
                     con4ecp=0;
                     for(i=0;i<pcountd4;i++)
                          c4pos[i]=undefined;
                     pcountd4=0;
if(c4w==820) l=12;else if(c4w==325) l=1;else if(c4w==370) l=2;else if(c4w==415) l=3;else if(c4w==460) l=4;else if(c4w==505)
l=5;else if(c4w==550) l=6;else if(c4w==595) l=7;else if(c4w==640) l=8;else if(c4w==685) l=9;else if(c4w==730) l=10;
else if(c4w==775) l=11;else l=0;
                     var alin4 = document.createElement('div');
                     al1="align4";
                     alin4.id=al1;
                     alin4.className = "align";
                     document.getElementById("container4").appendChild(alin4);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align4").innerHTML=astr; 
	     for(i=0,w=280;i<l;i++,w+=45)
                     { 
                       var c4alinp = document.createElement('div');
                       var al4="alp4"+(w+45);
                       c4alinp.id=al4;
                       c4alinp.className = "alignp";
                       document.getElementById("container4").appendChild(c4alinp);
                       $(document).ready(function(){$("#"+al4).css({"top":36,"left":w}); });                    
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al4).innerHTML=astp;
                     }
                   }
	   else if(key == "dec")
                   {
                    var f=0;
                    if(c4w <= 280)
                      alert("Device 1 min width");
                    else
                      {
                       $('#container4 > div').map(function() {
                       els=this.id;
                       aels=els.substring(0,3);
                       if(aels == "box")
                       {
                        t=$('#'+els).position().left;
                        if(c4w<=325 && t>=253)
                          f=1;
                        else if(c4w<=370 && t>=298)
                          f=1;   
                        else  if(c4w<=415 && t>=343)
                          f=1;   
                        else if(c4w<=460 && t>=388)
                          f=1;   
                        else  if(c4w<=505 && t>=433)
                          f=1;  
	      else if(c4w<=550 && t>=478)
                          f=1;   
                        else  if(c4w<=595 && t>=523)
                          f=1;   
                        else if(c4w<=640 && t>=568)
                          f=1;   
                        else  if(c4w<=685 && t>=613)
                          f=1;  
	      else if(c4w<=730 && t>=658)
                          f=1;   
                        else  if(c4w<=775 && t>=703)
                          f=1;  
	      else  if(c4w<=820 && t>=748)
                          f=1; 
                       }  }); 
                      if(f==0)
                      {
                        $( '#alp4'+c4w).remove(); 
                        c4w-=45;
                        c4pa--;
                        $(document).ready(function(){$("#container4").css({"height":130,"width": c4w}); });
                      }
                      else
                         alert("Move parts to the Left axis");
                      } 
                   } 
                     else if(key == "win" && c4pa <18)
                    {
                      c4alpw=c4w;
                      c4w+=45;
                      if(c4w >= 865)
	      alert("Device 4 Max width");
                      else
                       {
                      c4pa++;
                      $(document).ready(function(){$("#container4").css({"height":130,"width": c4w}); }); 
                       var c4alinp = document.createElement('div');
                       var al4="alp4"+c4w;
                       c4alinp.id=al4;
                       c4alinp.className = "alignp";
                       document.getElementById("container4").appendChild(c4alinp);
                       $(document).ready(function(){$("#"+al4).css({"top":36,"left":c4alpw}); });                    
                       var astp="<img src='SVG/alignp.jpg' alt=''/>"
                       document.getElementById(al4).innerHTML=astp;                      
                       }
                    }                              
        },
        items: { 
            "clear": {name: "Clear Device", icon: "clr"},
            "win": {name: "Width+", icon: "inc"},
            "dec": {name: "Width--", icon: "dec"} 
                    }
    });     });  

