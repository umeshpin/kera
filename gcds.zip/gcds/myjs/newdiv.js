function newDiv()
{
 if (newDiv.divcount == undefined)
 {
   newDiv.divcount = 0; 
 }
 
  newDiv.divcount++;
   if (newDiv.divcount == 1)
   {
   dev2 = document.createElement('div');
   t="container"+newDiv.divcount;
   dev2.id =t;
   dev2.className = "container";
 document.getElementById('device').appendChild(dev2);
    var alin1 = document.createElement('div');
                     al1="align1";
                     alin1.id=al1;
                     alin1.className = "align";
                     document.getElementById("container1").appendChild(alin1);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align1").innerHTML=astr;
    contr=1;
 jQuery('#container1').click(function () {
       jQuery('#container1').addClass('container');
       jQuery('#container2').removeClass('container');
       jQuery('#container3').removeClass('container');
       jQuery('#container4').removeClass('container');
    });                                              
  jsPlumb.ready(function () {
     ainstance.draggable($("#container1"),{ containment: "#device" }); }); 
 }
   else if(newDiv.divcount == 2)
   {
    dev2 = document.createElement('div');
   u ="container"+newDiv.divcount;
   dev2.id =u;
   document.getElementById('device').appendChild(dev2);
       var alin2 = document.createElement('div');
                     al2="align2";
                     alin2.id=al2;
                     alin2.className = "align";
                     document.getElementById("container2").appendChild(alin2);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align2").innerHTML=astr;
    document.getElementById('container1').onclick =function(){ contr=1; }
    document.getElementById('container2').onclick =function(){ contr=2; }
     jQuery('#container2').click(function () {
       jQuery('#container2').addClass('container');
       jQuery('#container1').removeClass('container');
       jQuery('#container3').removeClass('container');
       jQuery('#container4').removeClass('container');
    });
     jsPlumb.ready(function () {
       ainstance.draggable($("#container2"),{ containment: "#device" }); });
    }  
else if(newDiv.divcount == 3)
   {
     dev2 = document.createElement('div');
     v ="container"+newDiv.divcount;
     dev2.id =v;
     dev2.id ="container"+newDiv.divcount;
     document.getElementById('device').appendChild(dev2);
        var alin3 = document.createElement('div');
                     al3="align3";
                     alin3.id=al3;
                     alin3.className = "align";
                     document.getElementById("container3").appendChild(alin3);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align3").innerHTML=astr;

     document.getElementById('container1').onclick =function(){ contr=1; }
     document.getElementById('container2').onclick =function(){ contr=2; }
     document.getElementById('container3').onclick =function(){ contr=3; }       
       jQuery('#container3').click(function () {
       jQuery('#container3').addClass('container');
       jQuery('#container1').removeClass('container');
       jQuery('#container2').removeClass('container');
       jQuery('#container4').removeClass('container');
    });
        jsPlumb.ready(function () {
    ainstance.draggable($("#container3"),{ containment: "#device" }); })
   }
   else if(newDiv.divcount == 4)
   {
     dev2 = document.createElement('div');
     w ="container"+newDiv.divcount;
     dev2.id =w;
     dev2.id ="container"+newDiv.divcount;
     document.getElementById('device').appendChild(dev2);
        var alin4 = document.createElement('div');
                     al4="align4";
                     alin4.id=al4;
                     alin4.className = "align";
                     document.getElementById("container4").appendChild(alin4);
                     var astr="<img src='SVG/align.jpg' alt=''/>"
                     document.getElementById("align4").innerHTML=astr;
     document.getElementById('container1').onclick =function(){ contr=1; }
     document.getElementById('container2').onclick =function(){ contr=2; }
     document.getElementById('container3').onclick =function(){ contr=3; }
     document.getElementById('container4').onclick =function(){ contr=4; }
        jQuery('#container4').click(function () {
       jQuery('#container4').addClass('container');
       jQuery('#container1').removeClass('container');
       jQuery('#container3').removeClass('container');
       jQuery('#container2').removeClass('container');
    });      
    jsPlumb.ready(function () {
     ainstance.draggable($("#container4"),{ containment: "#device" }); });
   }
   else
   {
      newDiv.divcount = 4;
      alert("Max 4 Devices");
      return;
   }     
}