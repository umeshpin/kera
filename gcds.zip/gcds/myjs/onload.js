function loadFunct()
{
  workspace = document.createElement('svg');
  device="device";
  workspace.id=device;
  workspace.className="device";
  document.getElementById('page').appendChild(workspace);
$(document).ready(function() {
    $('#device').contextmenu(function(e) {  
      divmX=e.clientX;
      divmY=e.clientY;
    });
});
}