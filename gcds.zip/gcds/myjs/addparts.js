var parts;
var boxcat;
var top;
var left;
var w;
var ptp;
var pbp;
  
function myfunction(buttonId)
{
if (myfunction.count == undefined)
	{
		myfunction.count = 1;
	}
	else
	{
		myfunction.count++;
	}
bno=myfunction.count;
var iDiv = document.createElement('div');
boxid="box"+myfunction.count;

iDiv.id = boxid;
if(buttonId == "2" || buttonId == "9" || buttonId == "10" || buttonId == "11" || buttonId == "14" || buttonId == "18")
       boxcat = "bc1";  // if(buttonId == "2" || buttonId == "9")  {ptp= -23; pbp=43;} else if(buttonId == "10" || buttonId == "18"){ptp= -38; pbp=43;} else {ptp= -40; pbp=43;}    
else if(buttonId == "3" || buttonId == "6" || buttonId == "7" || buttonId == "8" )
       boxcat = "bc2";
else if(buttonId == "1" || buttonId == "4" || buttonId == "19")
       boxcat = "bc3"; 
else if(buttonId == "5" || buttonId == "20")
       boxcat = "bc4"; 
else if(buttonId == "13")
       boxcat = "bc6";
else if(buttonId == "17" || buttonId == "21")
       boxcat = "bc7";
else if(buttonId == "12" || buttonId == "16")
       boxcat = "bc8";
else
       boxcat = "bc5";
iDiv.className = boxcat;
scontr="container"+contr; 
if(buttonId == "1")
 parts='<svg id="svg1" class="parts" height="80" width="40"><path d="M 13 46 L 37 46 M 13 54 L 37 54" id="parta" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" transform="translate(-5,-32)"/></svg>'; 
else if(buttonId == "2")
 parts='<svg id="svg2" class="parts" height="80" width="40"><path d="M 19 37 L 22 37 L 22 63 L 19 63 M 31 37 L 28 37 L 28 63 L 31 63" id="partb" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>';
else if(buttonId == "3")
parts='<svg id="svg3" class="parts" height="80" width="36"><path d="M 9 65 L 27 65 L 42 50 L 27 35 L 9 35 L 9 65" id="partc" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-7,-25)"/></svg>'; 
else if(buttonId == "4")
 parts='<svg id="svg4" class="parts" height="80" width="40"><path d="M 10 46 L 40 46 M 25 54 L 40 54" id="partd" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-32)"/></svg>'; 
else if(buttonId == "5")
 parts='<svg id="svg5" class="parts" height="80" width="40"><path d="M 10 37 L 10 50 L 40 50 L 40 63" id="parte" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-8,-35)"/></svg>'; 
else if(buttonId == "6")
 parts='<svg id="svg6" class="parts" height="80" width="35"><path d="M 17 58 L 33 58 L 33 42 L 17 42 L 17 58 Z M 10 65 L 40 65 L 40 35 L 10 35 L 10 65 Z" id="partf" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-7,-25)"/></svg>'; 
else if(buttonId == "7")
 parts='<svg id="svg7" class="parts" height="80" width="35"><path d="M 10 65 L 40 65 L 40 35 L 10 35 L 10 65 Z" id="partg" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-8,-25)"/></svg>'; 
else if(buttonId == "8")
 parts='<svg id="svg8" class="parts" height="80" width="35"><circle cx="25" cy="50" r="15" id="cira" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-7,-25)"/></svg>'; 
else if(buttonId == "9")
 parts='<svg id="svg9" class="parts" height="80" width="40"><path d="M 12 45 L 38 45 L 28 38" id="parth" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>'; 
else if(buttonId == "10")
 parts='<svg id="svg10" class="parts" height="80" width="41"><path d="M 31.5 15.5 L 40 23 L 31.5 30.3333 M 10 50 L 10 23 L 39 23" id="parti" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>'; 
else if(buttonId == "11")
 parts='<svg id="svg11" class="parts" height="80" width="40"><path d="M 25 50 L 25 25 M 17 16 L 33 32 M 33 16 L 17 32" id="partj" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>'; 
else if(buttonId == "12")
 parts='<svg id="svg12" class="parts" height="80" width="40"><path d="M 25 50 L 25 34" id="partk" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/><circle cx="25" cy="25" r="7" id="cirb" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/ transform="translate(-5,-10)"></svg>'; 
else if(buttonId == "13")
 parts='<svg id="svg13" class="parts" height="80" width="40"><path d="M 25 37 L 25 63" id="partl" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-8,-35)"/></svg>'; 
else if(buttonId == "14")
 parts='<svg id="svg14" class="parts" height="80" width="40"><path d="M 25 50 L 25 45 M 25 38 L 25 33 M 17 16 L 33 32 M 33 16 L 17 32" id="partm" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>'; 
else if(buttonId == "15")
 parts='<svg id="svg15" class="parts" height="80" width="40"><path d="M 12 50 L 38 50 L 38 45 C 38 35 32 30 25 30 C 18 30 12 35 12 45 Z" id="partn" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-10,-23)"/></svg>'; 
else if(buttonId == "16")
 parts='<svg id="svg16" class="parts" height="80" width="40"><path d="M 25 50 L 25 46 M 25 41 L 25 37" id="parto" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/><circle cx="25" cy="25" r="7" id="circ" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>'; 
else if(buttonId == "17")
 parts='<svg id="svg17" class="parts" height="80" width="71"><path d="M 5 45 L 5 20 L 45 20 L 45 45 Z M 10 27 L 20 37 M 10 37 L 20 27 M 24 39 L 40 39" id="partp" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-3,-7)"/></svg>'; 
else if(buttonId == "18")
 parts='<svg id="svg18" class="parts" height="80" width="40"><path d="M 25 50 L 25 26 M 10 25 L 40 25" id="partq" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>'; 
else if(buttonId == "19")
 parts='<svg id="svg19" class="parts" height="80" width="40"><path d="M 10 46 L 40 46 M 25 54 L 10 54" id="partr" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-32)"/></svg>'; 
else if(buttonId == "20")
 parts='<svg id="svg20" class="parts" height="80" width="40"><path d="M 40 37 L 40 50 L 10 50 L 10 63" id="ps" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-8,-35)"/></svg>'; 
else 
 parts='<svg id="svg21" class="parts" height="80" width="71"><path d="M 5 40 L 5 60 L 45 60 L 45 40 Z" id="partt" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-3,-25)"/></svg>'; 
 

 $(function(){   
    $.contextMenu({
        selector: '#'+boxid, 
        callback: function(key, options) {
                       
                          pt=$(this).attr('id');
                          ptc=$(this).attr('class');
                          fc=ptc.substring(0,3);
                          epidn=pt.substring(3,5);
                          var ele=document.getElementById(pt);
                          //alert(pt);
                          if(fc== "bc1")
                           { 
                             bc1pid=$("#"+pt).find("svg").attr("id");
                             if(bc1pid == "svg2" || bc1pid == "svg9")
                               {ptp= -23; pbp=43;}
                             else if(bc1pid == "svg10" || bc1pid == "svg18")
	               {ptp= -38; pbp=43;}
	             else
	               {ptp= -40; pbp=43;} 
                           }
                          else if(fc== "bc2")
                           { ptp= -25; pbp=43;}
	          else if(fc== "bc3")
	           { ptp= -18; pbp=43;}
	          else if(fc== "bc4")
	           { ptp= -20; pbp=43;}
	          else if(fc== "bc5")
	           { ptp= -30; pbp=43;}
	          else if(fc== "bc6")
	           { ptp= -22; pbp=43;}
	          else if(fc== "bc7")
	           { ptp= -22; pbp=43;}
                          else if(fc== "bc8")
	           { ptp= -42; pbp=43;}

                          actp=ele.offsetLeft;     
                          pc=$(this).parent().attr('id');
                           if(pc == "container1")
                             contr=1;
                           else if(pc == "container2")
                             contr=2;
                           else if(pc == "container3")
                             contr=3;
                           else if(pc == "container4")
                             contr=4;
                         
                  if(key == "delete")
                   {
                     // t=$(this).attr('id');
                          $( '#'+pt ).remove();
                    if(pc == "container1")
                     {  
                        pcountd1--;
                        ainstance.deleteEndpoint(con1aep[epidn]);
 	      ainstance.deleteEndpoint(con1rep[epidn]);
                         con1epc--;
                        if(actp>=0 && actp <=54)
                          c1pos[0]=undefined;
                        else if(actp>=55 && actp <=99)
                          c1pos[1]=undefined;
                        else if(actp>=100 && actp <=144)
                          c1pos[2]=undefined;
	      else if(actp>=145 && actp <=189)
                          c1pos[3]=undefined;
	      else if(actp>=190 && actp <=234)
                          c1pos[4]=undefined;
                        else if(actp>=235 && actp <=279)
                          c1pos[5]=undefined;
                        else if(actp>=280 && actp <=324)
                          c1pos[6]=undefined;
                        else if(actp>=325 && actp <=369)
                          c1pos[7]=undefined;
	      else if(actp>=370 && actp <=414)
                          c1pos[8]=undefined;
	      else if(actp>=415 && actp <=459)
                          c1pos[9]=undefined;
                        else if(actp>=460 && actp <=504)
                          c1pos[10]=undefined;
                        else if(actp>=505 && actp <=549)
                          c1pos[11]=undefined;
                        else if(actp>=550 && actp <=594)
                          c1pos[12]=undefined;
	      else if(actp>=595 && actp <=639)
                          c1pos[13]=undefined;
	      else if(actp>=640 && actp <=684)
                          c1pos[14]=undefined;
	      else if(actp>=685 && actp <=729)
                          c1pos[15]=undefined;
                        else if(actp>=730 && actp <=774)
                          c1pos[16]=undefined;
	      else if(actp>=775 && actp <=819)
                          c1pos[17]=undefined;
	      else
                          c1pos[18]=undefined;
                     }
                    else if(pc == "container2")
                       { pcountd2--;
                         ainstance.deleteEndpoint(con2aep[epidn]);
                        ainstance.deleteEndpoint(con2rep[epidn]);
                         con2epc--;
                          if(actp>=0 && actp <=54)
                          c2pos[0]=undefined;
                        else if(actp>=55 && actp <=99)
                          c2pos[1]=undefined;
                        else if(actp>=100 && actp <=144)
                          c2pos[2]=undefined;
	      else if(actp>=145 && actp <=189)
                          c2pos[3]=undefined;
	      else if(actp>=190 && actp <=234)
                          c2pos[4]=undefined;
                        else if(actp>=235 && actp <=279)
                          c2pos[5]=undefined;
                        else if(actp>=280 && actp <=324)
                          c2pos[6]=undefined;
                        else if(actp>=325 && actp <=369)
                          c2pos[7]=undefined;
	      else if(actp>=370 && actp <=414)
                          c2pos[8]=undefined;
	      else if(actp>=415 && actp <=459)
                          c2pos[9]=undefined;
                        else if(actp>=460 && actp <=504)
                          c2pos[10]=undefined;
                        else if(actp>=505 && actp <=549)
                          c2pos[11]=undefined;
                        else if(actp>=550 && actp <=594)
                          c2pos[12]=undefined;
	      else if(actp>=595 && actp <=639)
                          c2pos[13]=undefined;
	      else if(actp>=640 && actp <=684)
                          c2pos[14]=undefined;
	      else if(actp>=685 && actp <=729)
                          c2pos[15]=undefined;
                        else if(actp>=730 && actp <=774)
                          c2pos[16]=undefined;
	      else if(actp>=775 && actp <=819)
                          c2pos[17]=undefined;
	      else
                          c2pos[18]=undefined;
                        }
                    else if(pc == "container3")
                       { 
                         pcountd3--;
                         ainstance.deleteEndpoint(con3aep[epidn]);
                         ainstance.deleteEndpoint(con3rep[epidn]);
                         con3epc--;
                         if(actp>=0 && actp <=54)
                          c3pos[0]=undefined;
                        else if(actp>=55 && actp <=99)
                          c3pos[1]=undefined;
                        else if(actp>=100 && actp <=144)
                          c3pos[2]=undefined;
	      else if(actp>=145 && actp <=189)
                          c3pos[3]=undefined;
	      else if(actp>=190 && actp <=234)
                          c3pos[4]=undefined;
                        else if(actp>=235 && actp <=279)
                          c3pos[5]=undefined;
                        else if(actp>=280 && actp <=324)
                          c3pos[6]=undefined;
                        else if(actp>=325 && actp <=369)
                          c3pos[7]=undefined;
	      else if(actp>=370 && actp <=414)
                          c3pos[8]=undefined;
	      else if(actp>=415 && actp <=459)
                          c3pos[9]=undefined;
                        else if(actp>=460 && actp <=504)
                          c3pos[10]=undefined;
                        else if(actp>=505 && actp <=549)
                          c3pos[11]=undefined;
                        else if(actp>=550 && actp <=594)
                          c3pos[12]=undefined;
	      else if(actp>=595 && actp <=639)
                          c3pos[13]=undefined;
	      else if(actp>=640 && actp <=684)
                          c3pos[14]=undefined;
	      else if(actp>=685 && actp <=729)
                          c3pos[15]=undefined;
                        else if(actp>=730 && actp <=774)
                          c3pos[16]=undefined;
	      else if(actp>=775 && actp <=819)
                          c3pos[17]=undefined;
	      else
                          c3pos[18]=undefined;
                       }
                    else if(pc == "container4")
                       { pcountd4--;
                         ainstance.deleteEndpoint(con4aep[epidn]);
                         ainstance.deleteEndpoint(con4rep[epidn]);
                         con4epc--;
                          if(actp>=0 && actp <=54)
                          c4pos[0]=undefined;
                        else if(actp>=55 && actp <=99)
                          c4pos[1]=undefined;
                        else if(actp>=100 && actp <=144)
                          c4pos[2]=undefined;
	      else if(actp>=145 && actp <=189)
                          c4pos[3]=undefined;
	      else if(actp>=190 && actp <=234)
                          c4pos[4]=undefined;
                        else if(actp>=235 && actp <=279)
                          c4pos[5]=undefined;
                        else if(actp>=280 && actp <=324)
                          c4pos[6]=undefined;
                        else if(actp>=325 && actp <=369)
                          c4pos[7]=undefined;
	      else if(actp>=370 && actp <=414)
                          c4pos[8]=undefined;
	      else if(actp>=415 && actp <=459)
                          c4pos[9]=undefined;
                        else if(actp>=460 && actp <=504)
                          c4pos[10]=undefined;
                        else if(actp>=505 && actp <=549)
                          c4pos[11]=undefined;
                        else if(actp>=550 && actp <=594)
                          c4pos[12]=undefined;
	      else if(actp>=595 && actp <=639)
                          c4pos[13]=undefined;
	      else if(actp>=640 && actp <=684)
                          c4pos[14]=undefined;
	      else if(actp>=685 && actp <=729)
                          c4pos[15]=undefined;
                        else if(actp>=730 && actp <=774)
                          c4pos[16]=undefined;
	      else if(actp>=775 && actp <=819)
                          c4pos[17]=undefined;
	      else
                          c4pos[18]=undefined;
                       }
                 
                   } 
                   else if(key == "delp")
                   {
                       if(contr == 1)
                      { 
                         if(con1aep[epidn]!=undefined || con1rep[epidn]!=undefined )
                         {   ainstance.deleteEndpoint(con1aep[epidn]);
                           ainstance.deleteEndpoint(con1rep[epidn]);
                           con1aep[epidn]=undefined;
                           con1rep[epidn]=undefined;
                           con1epc--;
                         }
                             
                         else 
	             alert("No end point");
                       }
   	else  if(contr == 2)
                     { 
                         if(con2aep[epidn]!=undefined || con2rep[epidn]!=undefined )
                         {   ainstance.deleteEndpoint(con2aep[epidn]);
                           ainstance.deleteEndpoint(con2rep[epidn]);
                           con2aep[epidn]=undefined;
                           con2rep[epidn]=undefined;
                           con2epc--;
                         }
                             
                         else 
	             alert("No end point");
                       }
                      
   	else if(contr == 3)
     	   { 
                         if(con3aep[epidn]!=undefined || con3rep[epidn]!=undefined )
                         {   
                           ainstance.deleteEndpoint(con3aep[epidn]);
                           ainstance.deleteEndpoint(con3rep[epidn]);
                           con3aep[epidn]=undefined;
                           con3rep[epidn]=undefined;
                           con3epc--;
                         }
                             
                         else 
	             alert("No end point");
                       
                      }
   	else if(contr == 4)
     	   { 
                          
                         if(con4aep[epidn]!=undefined || con4rep[epidn]!=undefined )
                         {   
                              ainstance.deleteEndpoint(con4aep[epidn]);
                              ainstance.deleteEndpoint(con4rep[epidn]);
                              con4aep[epidn]=undefined;
                              con4rep[epidn]=undefined;
                              con4epc--;
                         }
                             
                         else 
	             alert("No end point");
                       }           
                 } 
                  else if(key == "ren")  
                   {  nt=$(this).attr('id');
                       tn=nt.substring(3,5);
                       ts="name"+tn;              
                       document.getElementById(ts).value="";
                       document.getElementById(ts).focus();
                        
                    }  
                    else if(key == "rot")
                   { 
                       
                       var cn;
                       var tcn;
                       var top;
                       var roh=$("#"+pt).find("svg").attr("height"); 
                       var row=$("#"+pt).find("svg").attr("width"); 
                       if(roh=="80" && row=="36")
                       {       
                                 parts='<svg height="80" width="36.1"><path d="M 42,35 24,35 9,50 24,65 42,65 42,35 Z" id="cpartc" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-7,-25)"/></svg>'; 
                                 cn="bc2";      tcn="name7"; top='40px';

                        }
                       else if(roh=="80" && row=="36.1")
                      {    
                            parts='<svg height="80" width="36"><path d="M 9 65 L 27 65 L 42 50 L 27 35 L 9 35 L 9 65" id="partc" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-7,-25)"/></svg>';    
                            cn="bc2";      tcn="name7"; top='40px'
                      }
                       else if(roh=="80" && row=="41")
                       {     
                                 parts='<svg height="79" width="40"><path d="M 14 26 L 8 21 L 14 16 M 8 21 L 40 21 M 40 21 L 40 -3" id="cparti" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,44)"/></svg>'; 
                                 cn="bc1";         
		 tcn="name1"; top='25px'
                        }
                         else if(roh=="79" && row=="40")
                       {       
                                 parts='<svg height="80" width="41"><path d="M 31.5 15.5 L 40 23 L 31.5 30.3333 M 10 50 L 10 23 L 39 23" id="parti" stroke="#000000" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none" transform="translate(-5,-10)"/></svg>'; 
                                 cn="bc1";
		 tcn="name1";top='25px'
                        }
                        else
                       { 
                          alert("Unable to change orientation");
                          return;
                        }

                          var ele=document.getElementById(pt);
                          var scol=$("#"+pt).find("path").attr("stroke"); 
                          var fcol=$("#"+pt).find("path").attr("fill"); 
                          rotl=ele.offsetLeft;     
                          $( '#'+pt ).remove();
                          var iDiv = document.createElement('div');
                          iDiv.id = pt;
                          iDiv.className = cn;
                         iDiv.style.position = "absolute";
                         iDiv.style.left = rotl+'px';
	         iDiv.style.top = top;
                          document.getElementById(pc).appendChild(iDiv);
                           $('#'+pt).append(parts);
                          var cp=$("#"+pt).find("path").attr("id");
  	          document.getElementById(cp).setAttribute("stroke",scol); 
	          document.getElementById(cp).setAttribute("fill",fcol); 
                          var pid = document.getElementById(cp); pid.id ="path"+pt;
	          
                           dragbox='#'+scontr+' #'+boxid;
                           drag(dragbox)
                           .container(scontr)
                          .axis('x')
                            .bind() 
                           nt=$(this).attr('id');
                       tn=nt.substring(3,5);
                       ts="box"+tn;         
                          txt = document.createElement("input");
                       txt.setAttribute("type","text");
        	     txt.setAttribute("maxlength","7");
       	     txt.setAttribute("size","3");
                      //txt.setAttribute("value","name");
                       nm="name"+myfunction.count;
                       txt.id=nm; 
      	     //txt.value="name"; 
                     txt.className =tcn;
                       document.getElementById(ts).appendChild(txt);
                       document.getElementById(nm).onmouseover =function(){ if(this.value=="name")  this.value="";this.focus();}
        	     document.getElementById(nm).onmouseout =function(){ if(this.value=="")  this.value="name";}
        	     document.getElementById(nm).onblur =function(){ if(this.value=="")  this.value="name";}
     }                     
                  else if(key == "atop")
                   jsPlumb.ready(function ()    {  
           
                if(contr==1 && con1aep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==2 && con2aep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==3 && con3aep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==4 && con4aep[epidn] != undefined)
                 alert("End point exists");
             else {
             var connectorPaintStyle = {lineWidth: 1,strokeStyle: "#000000",joinstyle: "round",outlineColor: "white",outlineWidth: 2  };
     var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 6,lineWidth: 2},
            isSource: true,isTarget: true,parameters:{ "atsrc":pt },connector: [ "Flowchart", { stub: [40, 40], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
            connectorStyle: connectorPaintStyle,connectorOverlays: [ [ "Arrow", { location: 1} ] ]  };
      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything();
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }

    var p= actp+20; 
    ctr=pc;
    s=p/1000000;
    if(contr == 1)
    {
      
      con1epc++;
      con1aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource); 
      ainstance.fixEndpoints(ctr);
    }
   else if(contr == 2)
    {
      con2epc++;
      con2aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else  if(contr == 3)
    {
      con3epc++;
      con3aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else if(contr == 4)
    {
      con4epc++;
      con4aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    } }
  
     }); 
     else if(key == "abot")
      {
           jsPlumb.ready(function () { 
  
                if(contr==1 && con1rep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==2 && con2rep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==3 && con3rep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==4 && con4rep[epidn] != undefined)
                 alert("End point exists");
             else {
      var connectorPaintStyle = {lineWidth: 1,strokeStyle: "#000000",joinstyle: "round",outlineColor: "white",outlineWidth: 2  };
     var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 6,lineWidth: 2},
            isSource: true,isTarget: true,parameters:{ "absrc":pt},connector: [ "Flowchart", { stub: [40, 40], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
            connectorStyle: connectorPaintStyle,connectorOverlays: [ [ "Arrow", { location: 1} ] ]  };
            function fixEndpoints(parentnode) 
           { var endpoints = ainstance.getEndpoints(parentnode);
              var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource;});
              var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget; });
              calculateEndpoint(inputAr, true);
              calculateEndpoint(outputAr, false);
              ainstance.repaintEverything();
           }
           function calculateEndpoint(endpointArray, isInput) 
          {
            var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                                } 
                else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                       }       }    
            }
                  var p= actp+20;
                  ctr=pc;
                  t=-(p/1000000);
    if(contr == 1)
    {
      
      con1epc++;
      con1rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else if(contr == 2)
    {
      con2epc++;
      con2rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else  if(contr == 3)
    {
      con3epc++;
      con3rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else if(contr == 4)
    {
      con4epc++;
      con4rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
  }  
           }); 
       }
       else if(key == "rtop")
      {
          jsPlumb.ready(function ()    {  
           
                if(contr==1 && con1aep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==2 && con2aep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==3 && con3aep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==4 && con4aep[epidn] != undefined)
                 alert("End point exists");
             else {
             var connectorPaintStyle = { lineWidth: 1,strokeStyle: "#000000",joinstyle: "round",outlineColor: "white",outlineWidth: 2 };
          var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 6,lineWidth:2},
                 isSource: true,isTarget: true,parameters:{ "rtsrc":pt },connector: [ "Flowchart", { stub: [40, 40], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
                                                  connectorStyle: connectorPaintStyle,connectorOverlays: [   [ "Arrow", { location: 1,width: 18, length: .05} ] ]};
      function fixEndpoints(parentnode) 
     {  var endpoints = ainstance.getEndpoints(parentnode);
         var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource; });
            var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget;});
            calculateEndpoint(inputAr, true);
           calculateEndpoint(outputAr, false);
            ainstance.repaintEverything();
      }
     function calculateEndpoint(endpointArray, isInput)
    {
           var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                } else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                }         }
      }

    var p= actp+20; 
    ctr=pc;
    s=p/1000000;
    if(contr == 1)
    {
      
      con1epc++;
      con1aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource);
      ainstance.fixEndpoints(ctr);
    }
   else if(contr == 2)
    {
      con2epc++;
      con2aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else  if(contr == 3)
    {
      con3epc++;
      con3aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else if(contr == 4)
    {
      con4epc++;
      con4aep[epidn]=ainstance.addEndpoint(ctr,{anchor:[s,0.5,0,-1,p,ptp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    } }
  
     }); 
       }
            else if(key == "rbot")
                   jsPlumb.ready(function () { 
  
                if(contr==1 && con1rep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==2 && con2rep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==3 && con3rep[epidn] != undefined)
                 alert("End point exists");
                else if(contr==4 && con4rep[epidn] != undefined)
                 alert("End point exists");
             else {
          var connectorPaintStyle = { lineWidth: 1,strokeStyle: "#000000",joinstyle: "round",outlineColor: "white",outlineWidth: 2 };
          var anEndpointSource = {endpoint: "Dot",paintStyle: {strokeStyle: "#FFFFFF",fillStyle: "#dcd5d5",radius: 6,lineWidth:2},
                 isSource: true,isTarget: true,parameters:{ "rbsrc":pt },connector: [ "Flowchart", { stub: [40, 40], gap: 10, cornerRadius: 5, alwaysRespectStubs: false } ],
                                                  connectorStyle: connectorPaintStyle,connectorOverlays: [   [ "Arrow", { location: 1,width: 18, length: .05} ] ]};
            function fixEndpoints(parentnode) 
           { var endpoints = ainstance.getEndpoints(parentnode);
              var inputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isSource;});
              var outputAr = $.grep(endpoints, function (elementOfArray, indexInArray) {
                return elementOfArray.isTarget; });
              calculateEndpoint(inputAr, true);
              calculateEndpoint(outputAr, false);
              ainstance.repaintEverything();
           }
           function calculateEndpoint(endpointArray, isInput) 
          {
            var mult = 1 / (endpointArray.length+1);
            for (var i = 0; i < endpointArray.length; i++) {
                if (isInput) {
                    endpointArray[i].anchor.x = 1;
                    endpointArray[i].anchor.y = mult * (i + 1);
                                } 
                else {
                    endpointArray[i].anchor.x = 0;
                    endpointArray[i].anchor.y = mult * (i + 1);
                       }       }    
            }
                  var p= actp+20;
                  ctr=pc;
                  t=-(p/1000000);
    if(contr == 1)
    {
      
      con1epc++;
      con1rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else if(contr == 2)
    {
      con2epc++;
      con2rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else  if(contr == 3)
    {
      con3epc++;
      con3rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
   else if(contr == 4)
    {
      con4epc++;
      con4rep[epidn]=ainstance.addEndpoint(ctr,{anchor:[t,0.5,0,1,p,pbp]},anEndpointSource);
      ainstance.fixEndpoints(ctr); 
    }
  }  
           }); 
     else if(key == "r")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "red");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "red");
     }
    else if(key == "b")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "blue");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "blue");
     }
       else if(key == "g")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "green");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "green");
     }
    else if(key == "y")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "gold");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "gold");
     }
  else if(key == "v")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "violet");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "violet");
     }
      else if(key == "d")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "black");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "black");
     }
  else if(key == "dy")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "goldenrod");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "goldenrod");
     }
     else if(key == "db")
     {
        var cp=$("#"+pt).find("path").attr("id");
        var cc=$("#"+pt).find("circle").attr("id"); 
        if(cp!=undefined)
            document.getElementById(cp).setAttribute("stroke", "darkblue");
        if(cc!=undefined)
            document.getElementById(cc).setAttribute("stroke", "darkblue");
     }
      else if(key == "fr")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "red");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "red");
         }
     }
      else if(key == "fb")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "blue");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "blue");
         }
     }
  else if(key == "fg")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "green");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "green");
         }
     }
      else if(key == "fy")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "gold");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "gold");
         }
     }
    else if(key == "fv")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "violet");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "violet");
         }
     }
      else if(key == "fd")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "black");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "black");
         }
     }
  else if(key == "fdy")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "goldenrod");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "goldenrod");
         }
     }
      else if(key == "fdb")
     { if(fc == "bc2" || fc == "bc5" || fc == "bc7" || fc == "bc8")
        {
            var cp=$("#"+pt).find("path").attr("id");
            var cc=$("#"+pt).find("circle").attr("id"); 
            if(cp!=undefined)
               document.getElementById(cp).setAttribute("fill", "darkblue");
            if(cc!=undefined)
            document.getElementById(cc).setAttribute("fill", "darkblue");
         }
     }
        },
        items: { 
            "delete": {name: "Remove", icon: "rmv"},     
            "ren": {name: "Rename", icon: "ren"}, 
            "fcol": {name: "Fill Color", icon: "fcol",
                    "items": {
                        "fr": {"name": "Red", icon: "red"},     
                        "fb": {"name": "Blue", icon: "blu"},
                        "fv": {"name": "Violet", icon: "vio"},   
                        "fy": {"name": "Yellow", icon: "yel"},
                        "fg": {"name": "Green", icon: "gre"},
                        "fd": {"name": "Black", icon: "def"},
                        "fdb": {"name": "Dark Blue", icon: "dbl"},
                        "fdy": {"name": "Dark Yellow", icon: "dye"},       
                                }
                     },
            "act": {name: "Activation", icon: "act",
                     "items": {
                    "atop": {"name": "Top", icon: "top"},
                    "abot": {"name": "Bottom", icon: "bot"},         
                               }
                      },
             "rep": {name: "Repression", icon: "rep",
                    "items": {
                    "rtop": {"name": "Top", icon: "top"},
                    "rbot": {"name": "Bottom", icon: "bot"},         
                               }
                      },
             "col": {name: "Change Color", icon: "col",
                    "items": {
                        "r": {"name": "Red", icon: "red"},     
                        "b": {"name": "Blue", icon: "blu"},
                        "v": {"name": "Violet", icon: "vio"},   
                        "y": {"name": "Yellow", icon: "yel"},
                        "g": {"name": "Green", icon: "gre"},
                        "d": {"name": "Black", icon: "def"},
                        "db": {"name": "Dark Blue", icon: "dbl"},
                        "dy": {"name": "Dark Yellow", icon: "dye"},       
                                }
                     },
            "delp": {name: "Delete End Point", icon: "del"},
            "rot": {name: "Reverse Orientation", icon: "rot"}
          
           }
    });    
 }); 

if(boxcat== "bc1" || boxcat== "bc8")
   top=35;
else if(boxcat == "bc3")
   top=47;
else if(boxcat == "bc5")
   top=38;
else 
   top=50; 

 

if(contr ==1 && pcountd1 < c1pa)
 {
    
   for(i=0,left=10;i<=pcountd1;i++,left+=45)
   {
     if(c1pos[i]==undefined)
     {    c1pos[i]=boxid;        
           break;
     }
    }
   document.getElementById("container1").appendChild(iDiv);
   $('#'+boxid).append(parts);
   var cp=$("#"+boxid).find("path").attr("id");
   var cc=$("#"+boxid).find("circle").attr("id");
   if(cp!=undefined)
   { document.getElementById(cp).setAttribute("stroke", "black"); var pid = document.getElementById(cp); pid.id ="path"+boxid; }
   if(cc!=undefined)
   { document.getElementById(cc).setAttribute("stroke", "black"); var cid = document.getElementById(cc);  cid.id ="cir"+boxid;}
   pcountd1++; 
   $(document).ready(function(){$("#"+boxid).css({"top": top, "left": left}); });  
 }  

else if(contr==2 && pcountd2 < c2pa)


 {
  for(i=0,left=10;i<=pcountd2;i++,left+=45)
   {
     if(c2pos[i]==undefined)
     {    c2pos[i]=boxid;        
           break;
     }
   }
  document.getElementById("container2").appendChild(iDiv);
    $('#'+boxid).append(parts); 
   var cp=$("#"+boxid).find("path").attr("id");
   var cc=$("#"+boxid).find("circle").attr("id");
   if(cp!=undefined)
   {    document.getElementById(cp).setAttribute("stroke", "black"); var pid = document.getElementById(cp); pid.id ="path"+boxid; }
   if(cc!=undefined)
   {  document.getElementById(cc).setAttribute("stroke", "black");  var cid = document.getElementById(cc);  cid.id ="cir"+boxid;}
   pcountd2++; 
   $(document).ready(function(){$("#"+boxid).css({"top": top, "left": left}); }); 
 }
else if(contr==3 && pcountd3 < c3pa)
 {
  for(i=0,left=10;i<=pcountd3;i++,left+=45)
   {
     if(c3pos[i]==undefined)
     {    c3pos[i]=boxid;        
           break;
     }
   }
  document.getElementById("container3").appendChild(iDiv);
    $('#'+boxid).append(parts); 
  var cp=$("#"+boxid).find("path").attr("id");
   var cc=$("#"+boxid).find("circle").attr("id");
   if(cp!=undefined)
   {    document.getElementById(cp).setAttribute("stroke", "black"); var pid = document.getElementById(cp); pid.id ="path"+boxid; }
   if(cc!=undefined)
   {   document.getElementById(cc).setAttribute("stroke", "black"); var cid = document.getElementById(cc);  cid.id ="cir"+boxid;}
   pcountd3++; 
   $(document).ready(function(){$("#"+boxid).css({"top": top, "left": left}); }); 
  }
else if(contr==4 && pcountd4 < c4pa)
 {
for(i=0,left=10;i<=pcountd4;i++,left+=45)
   {
     if(c4pos[i]==undefined)
     {    c4pos[i]=boxid;        
           break;
     }
   }
  document.getElementById("container4").appendChild(iDiv);
   $('#'+boxid).append(parts);  
   var cp=$("#"+boxid).find("path").attr("id");
   var cc=$("#"+boxid).find("circle").attr("id");
   if(cp!=undefined)
   {    document.getElementById(cp).setAttribute("stroke", "black"); var pid = document.getElementById(cp); pid.id ="path"+boxid; }
   if(cc!=undefined)
   {  document.getElementById(cc).setAttribute("stroke", "black");  var cid = document.getElementById(cc);  cid.id ="cir"+boxid;}
   pcountd4++; 
   $(document).ready(function(){$("#"+boxid).css({"top": top, "left": left}); }); 
 }
else if(contr==0)
  alert("no devices");
else
{ alert("Device "+contr+" Max parts");} 

        txt = document.createElement("input");
        txt.setAttribute("type","text");
        txt.setAttribute("maxlength","7");
        txt.setAttribute("size","3");
        txt.setAttribute("value","name");
        nm="name"+myfunction.count;
        txt.id=nm; 
        //txt.value="name";

        if(buttonId == "2" || buttonId == "9" || buttonId == "10" || buttonId == "11" || buttonId == "12" || buttonId == "14" || buttonId == "16" || buttonId == "18")
           txt.className ="name1";
        else if(buttonId == "6" || buttonId == "8")
           txt.className ="name2";
        else if(buttonId == "1" || buttonId == "4" || buttonId == "19")
          txt.className ="name3";
        else if(buttonId == "5" || buttonId == "13" || buttonId == "20")
          txt.className ="name4";
        else if(buttonId == "3" || buttonId == "7" || buttonId == "17" || buttonId == "21")
          txt.className ="name7";
        else 
          txt.className ="name5";
        document.getElementById(boxid).appendChild(txt);
        document.getElementById(nm).onmouseover =function(){ if(this.value=="name")  this.value="";this.focus();}
        document.getElementById(nm).onmouseout =function(){ if(this.value=="")  this.value="name";}
        document.getElementById(nm).onblur =function(){ if(this.value=="")  this.value="name";}
   
            dragbox='#'+scontr+' #'+boxid;
            drag(dragbox)
            .container(scontr)
           .axis('x')
           .bind() 
}




