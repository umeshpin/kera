$(document).ready(function() {
    $('#mn7').click(function() { 
    alert("V 2.0");
    /*  $( "#device" ).load( "temp.html" );
     newDiv.divcount = 1;
     scontr="container1";
    */
});
});