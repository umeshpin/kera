$(document).ready(function() {
    $('#mn6').click(function() { 
  var xmlfc="<container>";
  var wscnt = document.getElementById("device").innerHTML; 
  //alert(wscnt);
 /*  var pname1 = $("#container1").find('input');
  pname1.each(function () {
   alert($(this).val());
  }); 
  */
 for(i=1;i<=newDiv.divcount;i++)
 {
     var cnt=0; var nmar = []; var acnt = 0; var span,epan;
     tmpc="<device"+i+">"; 
     var partsc = $("#container"+i).find('.parts');
     var pname = $("#container"+i).find('input');
     pname.each(function () {  nmar[cnt++]=$(this).val();  });
     partsc.each(function () { 
     pan=$(this).attr('id'); 
     if(pan == "svg1") { span="<parts:Assenbly-Scar>"; epan="</parts:Assenbly-Scar>";} else if(pan == "svg2") { span="<parts:BRSite>"; epan="</parts:BRSite>"; }
     else if(pan == "svg3") { span="<parts:CDS>"; epan="</parts:CDS>"; } else if(pan == "svg4") { span="<parts:5PrimeOH>"; epan="</parts:5PrimeOH>"; }
     else if(pan == "svg5") { span="<parts:5PrimeSRSite>"; epan="</parts:5PrimeSRSite>"; } else if(pan == "svg6") { span="<parts:Insulator>"; epan="</parts:Insulator>"; }
     else if(pan == "svg7") { span="<parts:Operator>"; epan="</parts:Operator>"; } else if(pan == "svg8") { span="<parts:Replication>"; epan="</parts:Replication>"; }
     else if(pan == "svg9") { span="<parts:PBSite>"; epan="</parts:PBSite>"; } else if(pan == "svg10") { span="<parts:Promoter>"; epan="</parts:Promoter>"; }
     else if(pan == "svg11") { span="<parts:Protease-Site>"; epan="</parts:Protease-Site>"; } else if(pan == "svg12") { span="<parts:PSElement>"; epan="</parts:PSElement>"; }
     else if(pan == "svg13") { span="<parts:RER-Site>"; epan="</parts:RER-Site>"; } else if(pan == "svg14") { span="<parts:RiboNuclease-Site>"; epan="</parts:RiboNuclease-Site>"; }
     else if(pan == "svg15") { span="<parts:RE-Site>"; epan="</parts:RE-Site>"; } else if(pan == "svg16") { span="<parts:RNA-StabilityElement>"; epan="</parts:RNA-StabilityElement>"; }
     else if(pan == "svg17") { span="<parts:Signature>"; epan="</parts:Signature>"; } else if(pan == "svg18") { span="<parts:Terminator>"; epan="</parts:Terminator>"; }
     else if(pan == "svg19") { span="<parts:3PrimeOH>"; epan="</parts:3PrimeOH>"; } else if(pan == "svg20") { span="<parts:3PrimeSR-Site>"; epan="</parts:3PrimeSR-Site>"; }
     else if(pan == "svg21") { span="<parts:User-Defined>"; epan="</parts:User-Defined>"; }
     tmpc+=span;
     tmpc+=nmar[acnt++];
     tmpc+=epan; 
    });
    tmpc+="</device"+i+">";
    xmlfc+=tmpc; 
 } 
  var pmar = [];
  var pmcnt=1;
  var pms = $("#device").find('.abox');
  pms.each(function () { 
   pmids=$(this).attr('id');
   opmids=pmids.slice(0,6);//alert("hi");
   if(opmids == "addbox")
   {
          var pmimg = $("#"+pmids).find('img');
          var pmname = $("#"+pmids).find('input');
          var pmxn;
          pmname.each(function () {  pmxn=$(this).val();  });
          pmimg.each(function () {  if($(this).attr('id') =="pro") xmlfc+="<protein>"+pmxn+"</protein>"; else xmlfc+="<molecule>"+pmxn+"</molecule>"  });
             
   }
  });
   xmlfc+="<connections>";
  jsPlumb.ready(function () {
     cnnctns = ainstance.getConnections();
     var conntp;
     var cnsrc;
     var cntgt;
   
     for(i=0; i<cnnctns.length; i++) 
     {
          ptgt = (cnnctns[i].targetId).substring(0,3); 
          psrc = (cnnctns[i].sourceId).substring(0,3); 
          if(psrc == "con" && ptgt == "con") 
          {
            var sparm=cnnctns[i].endpoints[0].getParameters();
            if(sparm.atsrc!=undefined)
             {  conntp="activation"; cnsrc=sparm.atsrc; }
            else if(sparm.absrc!=undefined)
             {  conntp="activation"; cnsrc=sparm.absrc; }
            else if(sparm.rtsrc!=undefined)
             {  conntp="repression"; cnsrc=sparm.rtsrc; }
            else if(sparm.rbsrc!=undefined)
             {  conntp="repression"; cnsrc=sparm.rbsrc; }

            var tparm=cnnctns[i].endpoints[1].getParameters();
            if(tparm.atsrc!=undefined)
             {   cntgt=tparm.atsrc; }
            else if(tparm.absrc!=undefined)
             {   cntgt=tparm.absrc; }
            else if(tparm.rtsrc!=undefined)
             {   cntgt=tparm.rtsrc; }
            else if(tparm.rbsrc!=undefined)
             {   cntgt=tparm.rbsrc; }
           }
           else  if(psrc == "con" && ptgt == "add")
           {
            var sparm=cnnctns[i].endpoints[0].getParameters();
            if(sparm.atsrc!=undefined)
             {  conntp="activation"; cnsrc=sparm.atsrc; }
            else if(sparm.absrc!=undefined)
             {  conntp="activation"; cnsrc=sparm.absrc; }
            else if(sparm.rtsrc!=undefined)
             {  conntp="repression"; cnsrc=sparm.rtsrc; }
            else if(sparm.rbsrc!=undefined)
             {  conntp="repression"; cnsrc=sparm.rbsrc; }
               
              cntgt = cnnctns[i].targetId;
            }
            else  if(psrc == "add" && ptgt == "con")
            {
              cnsrc = cnnctns[i].sourceId;
              var sparm=cnnctns[i].endpoints[0].getParameters();
              var tparm=cnnctns[i].endpoints[1].getParameters();
              if(sparm.pmatsrc!=undefined)
                {  conntp="activation";  }

              else if(sparm.pmabsrc!=undefined)
                {  conntp="activation";  }
              else if(sparm.pmrtsrc!=undefined)
                {  conntp="repression"; }
              else if(sparm.pmrbsrc!=undefined)
                {  conntp="repression"; }

              if(tparm.atsrc!=undefined)
              {   cntgt=tparm.atsrc; }
              else if(tparm.absrc!=undefined)
              {   cntgt=tparm.absrc; }
              else if(tparm.rtsrc!=undefined)
              {   cntgt=tparm.rtsrc; }
              else if(tparm.rbsrc!=undefined)
              {   cntgt=tparm.rbsrc; }
             }
             else if(psrc == "add" && ptgt == "add")
             {
               var sparm=cnnctns[i].endpoints[0].getParameters();
               cnsrc = cnnctns[i].sourceId;  
               cntgt = cnnctns[i].targetId;
               if(sparm.pmatsrc!=undefined)
                {  conntp="activation";  }
               else if(sparm.pmabsrc!=undefined)
                {  conntp="activation";  }
               else if(sparm.pmrtsrc!=undefined)
                {  conntp="repression"; }
               else if(sparm.pmrbsrc!=undefined)
                {  conntp="repression"; }
             }
            cnsrcnm = $($("#"+cnsrc).find('input')).val();
            cntgtnm = $($("#"+cntgt).find('input')).val();
            xmlfc+="<"+cnsrcnm+">";
            xmlfc+=conntp;
            xmlfc+="<"+cntgtnm+">";  
        } });
  
 xmlfc+="</connections>"; 
 xmlfc+="</container>";
 
 var blob = new Blob([xmlfc], {type: "text/plain;charset=utf-8"});
 saveAs(blob, "workflow.xml"); 

 }); 

});
