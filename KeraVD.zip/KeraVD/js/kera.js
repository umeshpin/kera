
var scale = 1;
var flow_shapes = { 
    ascar: function () { return "M 13 46 L 37 46 M 13 54 L 37 54 "; },
    brs: function () { return "M 19 37 L 22 37 L 22 63 L 19 63 M 31 37 L 28 37 L 28 63 L 31  63"; },
    cds: function () { return "M 9 65 L 27 65 L 42 50 L 27 35 L 9 35 L 9 65 Z"; },
    fovr: function () { return "M 10 46 L 40 46 M 25 54 L 40 54"; },
    fsrs: function () { return "M 10 37 L 10 50 L 40 50 L 40 63"; },
    insulator: function () { return "M 17 58 L 33 58 L 33 42 L 17 42 L 17 58 Z M 10 65 L 40 65 L 40 35 L 10 35 L 10 65 Z"; },
    opr: function () { return "M 15 60 L 35 60 L 35 40 L 15 40 L 15 60 Z"; },
    ror: function () { return "M13,50a12,12 0 1,0 24,0a12,12 0 1,0 -24,0"; },
    pbs: function () { return "M 12 45 L 38 45 L 28 38"; },
    promoter: function () { return "M 31.5 15.5 L 40 23 L 31.5 30.3333 M 10 50 L 10 23 L 39 23"; },
    psite: function () { return "M 25 50 L 25 25 M 17 16 L 33 32 M 33 16 L 17 32 "; },
    pse: function () { return "M 25 50 L 25 34 M18,25a7,7 0 1,0 14,0a7,7 0 1,0 -14,0"; },
    rers: function () { return "M 25 37 L 25 63"; },
    rbcls: function () { return "M 25 50 L 25 45 M 25 38 L 25 33 M 17 16 L 33 32 M 33 16 L 17 32 "; },
    rse: function () { return "M 25 50 L 25 46 M 25 41 L 25 37 M18,25a7,7 0 1,0 14,0a7,7 0 1,0 -14,0"; },
    sig: function () { return "M 5 45 L 5 20 L 45 20 L 45 45 Z M 10 27 L 20 37 M 10 37 L 20 27 M 24 39 L 40 39"; },
    term: function () { return "M 25 50 L 25 26 M 10 25 L 40 25"; },
    tovr: function () { return "M 10 46 L 40 46 M 25 54 L 10 54"; },
    tsrs: function () { return "M 40 37 L 40 50 L 10 50 L 10 63"; },
    ud: function () { return "M 5 40 L 5 60 L 45 60 L 45 40 Z"; },
    rbs: function () { return "M 12 50 L 38 50 L 38 45 C 38 35 32 30 25 30 C 18 30 12 35 12 45  Z" },
    rep: function (from, to) {
        x1 = eval(getNodebyCode(from)[0].x) + 25*scale; y1 = eval(getNodebyCode(from)[0].y)-15*scale  , x2 = eval(getNodebyCode(to)[0].x) +25*scale, y2 = eval(getNodebyCode(to)[0].y)-15*scale;
        return "M " + x1 + " " + y1 + " L " + x1 + " " + eval(y1 - 30*scale) + " L " + x2 + " " + eval(y1 - 30*scale) + " L " + x2 + " " + y2 + " M " + eval(x2-10) + " " + y2 + " L " + eval(x2+10) + " " + y2;
    },
    ind: function (from, to) {
        x1 = eval(getNodebyCode(from)[0].x) + 25*scale; y1 = eval(getNodebyCode(from)[0].y)-15*scale  , x2 = eval(getNodebyCode(to)[0].x) +25*scale, y2 = eval(getNodebyCode(to)[0].y)-15*scale;
        return "M " + x1 + " " + y1 + " L " + x1 + " " + eval(y1 - 30 * scale) + " L " + x2 + " " + eval(y1 - 30 * scale) + " L " + x2 + " " + y2 + " M " + eval(x2 - 10) + " " + eval(y2 - 10) + " L " + x2 + " " + y2 + " M " + eval(x2 + 10) + " " + eval(y2 - 10) + " L " + x2 + " " + y2;
    },
    bod: function (from, to) {
        x1 = eval(getNodebyCode(from)[0].x) - 48 * scale; y1 = eval(getNodebyCode(from)[0].y) - 48 * scale, x2 = eval(getNodebyCode(to)[0].x) + 96 * scale, y2 = eval(getNodebyCode(to)[0].y) + 144 * scale;
        return "M " + x1 + " " + y1 + " L " + x1 + " " + y2 + " L " + x2 + " " + y2 + " L " + x2 + " " + y1 + " L " + x1 + " " + y1
    }
}
    
var flow_base = {
    ascar: function () { return "M -25 50 L 12 50 M 38 50 L 75 50"; },
    brs: function () { return "M -25 50 L 18 50 M 32 50 L 75 50"; },
    cds: function () { return "M -25 50 L 8 50 M 43 50 L 75 50"; },
    fovr: function () { return "M -25 50 L 9 50 M 41 50 L 75 50"; },
    fsrs: function () { return "M -25 50 L 9 50 M 41 50 L 75 50"; },
    insulator: function () { return "M -25 50 L 9 50 M 41 100 L 50 50"; },
    opr: function () { return "M -25 50 L 14 50 M 36 50 L 75 50"; },
    ror: function () { return "M -25 50 L 12 50 M 38 50 L 75 50"; },
    pbs: function () { return "M -25 50 L 11 50 M 39 50 L 75 50"; },
    promoter: function () { return "M -25 50 L 75 50"; },
    psite: function () { return "M -25 50 L 75 50"; },
    pse: function () { return "M -25 50 L 75 50"; },
    rers: function () { return "M -25 50 L 75 50"; },
    rbcls: function () { return "M -25 50 L 75 50"; },
    rse: function () { return "M -25 50 L 75 50"; },
    sig: function () { return "M -25 50 L 75 50"; },
    term: function () { return "M -25 50 L 75 50"; },
    tovr: function () { return "M -25 50 L 9 50 M 41 50 L 75 50"; },
    tsrs: function () { return "M -25 50 L 9 50 M 41 50 L 75 50"; },
    ud: function () { return "M -25 50 L 4 50 M 46 50 L 75 50"; },
    rbs: function () { return "M -25 50 L 11 50 M 39 50 L 75 50" },
    rep: function (from, to) { return "" }, ind: function (from, to) { return "" }, bod: function (from, to) { return "" }
}

var nodes = [];
/*var nodes = [
  { NodeType: "ascar", x: 50 * scale, y: 50 * scale, color: "blue", desc: "asc1" },
  { NodeType: "brs", x: 100 * scale, y: 50 * scale, color: "red" },
  { NodeType: "cds", x: 150 * scale, y: 50 * scale, color: "blue" },
  { NodeType: "fovr", x: 200 * scale, y: 50 * scale, color: "red" },
{ NodeType: "fsrs", x: 250 * scale, y: 50 * scale, color: "blue", desc: "asc2" },
{ NodeType: "bod", from: "asc1", to: "asc2", color: "red" },
  { NodeType: "insulator", x: 300, y: 50,  color: "red" },
{ NodeType: "opr", x: 350, y: 50,  color: "blue" },
  { NodeType: "ror", x: 400, y: 50,  color: "red" },
{ NodeType: "pbs", x: 450, y: 50,  color: "blue" },
  { NodeType: "promoter", x: 500, y: 50,  color: "red" },
{ NodeType: "psite", x: 550, y: 50,  color: "blue" },
  { NodeType: "pse", x: 600, y: 50,  color: "red" },
{ NodeType: "rers", x: 650, y: 50,  color: "blue" },
  { NodeType: "rbcls", x: 700, y: 50,  color: "red" ,desc:"asc2" },
{ NodeType: "rse", x: 750, y: 50,  color: "blue" },
  { NodeType: "sig", x: 800, y: 50,  color: "red" },
{ NodeType: "term", x: 850, y: 50,  color: "blue" },
  { NodeType: "tovr", x: 900, y: 50,  color: "red"  },
{ NodeType: "tsrs", x: 950, y: 50,  color: "blue" },
  { NodeType: "ud", x: 1000, y: 50, color: "red" },
{ NodeType: "rbs", x: 1050, y: 50, color: "red" },
{ NodeType: "ind", from: "asc1", to: "asc2", color: "red" }
]*/

function buildNodesfromMarkup(markup)
{
    nodes = [];

    var x = 150, y = 100;
    var lines = markup.split("\n");
    for (i = 0; i < lines.length; i++) {
        var comp = lines[i].split(":");
        var ops,code;
        if (comp[0]=="device")
        {
            var dev = comp[1];
            i++; k = 1; startx = x; starty = y;
            if (lines[i]=="{")
            {
                i++; j = i; 
                do{
                    var nodecomp = lines[i].split("(");
                    nt = nodecomp[0];
                    ops = nodecomp[1].replace(")", "").split(",");
                    var rev = false;
                    if (ops[1] == "<") { rev = true; }
                    code = dev + '.' + ops[0];
                    if (i == j) devstart = code ;
                    var nodetext = '{"id":"' + k +'","code":"'+ code  +'","NodeType":"' + nt + '","x":"' + x + '","y":"' + y + '","color":"' + ops[2] + '","desc":"' + ops[0] + '","rev":"' + rev + '"}'
                    nodes.push(JSON.parse(nodetext));
                    x += 100;
                    i++; k++;
                } while (lines[i] != "}")
                devend = code;
                var nodetext = '{"id":"' + k + '","NodeType":"bod","from":"' + devstart + '","to":"' + devend + '","desc":"' + dev + '","x":"' + startx + '","y":"' + starty + '","color":"black"}'
                nodes.push(JSON.parse(nodetext));
                k++;
            }
            x += 150;
            y += 100;
        }
        else if (comp[0]=="regulations")
        {
            i++;
            if (lines[i] == "{") {
                i++; 
                do {
                    var nodecomp = lines[i].split("-");
                    var from = nodecomp[0];
                    var to = nodecomp[1].substr(1);
                    var op = nodecomp[1].substr(0, 1);
                    if (op == ">") var nt = "ind"; else var nt = "rep";
                    var nodetext = '{"NodeType":"' + nt + '","from":"' + from + '","to":"' + to + '","color":"black"}'
                    nodes.push(JSON.parse(nodetext));
                    i++;
                } while (lines[i] != "}")
            }
        }

    }
}
function getNodebyCode(code)
{
    return nodes.filter(
            function(data){return data.code == code}
        );
}

function nsResolver(prefix) {
    var ns = {
        'rdf': 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
        'sbol': 'http://sbols.org/v2#',
        'dcterms':'http://purl.org/dc/terms/'
    };
    return ns[prefix] || null;
}
var SOmap =
    {
        "SO0000167": "promoter",
        "SO0000057": "opr",
        "SO0000316": "cds",
        "SO0000139": "rbs",
        "SO0000141": "term",
        "SO0000627": "insulator",
        "SO0001957": "rse",
        "SO0001956": "psite",
        "SO0001955": "pse",
        "SO0000296": "ror",
        "SO0005850": "pbs",
        "SO0001687": "rers",
        "SO0001691": "brs",
        "SO0001933": "fovr",
        "SO0001932": "tover",
        "SO0001953": "ascar"
    }
function buildMarkupfromSBOL(xml)
{
    //var xml = document.getElementById("txtSeq").value.toLowerCase();
    var markup = "";
    xmlDoc = $.parseXML(xml);
    $xml = $(xmlDoc);
    $components = $xml.xpath("/rdf:rdf/sbol:componentdefinition[@rdf:about=/rdf:rdf/sbol:componentdefinition/sbol:component/sbol:component/sbol:definition/@rdf:resource[/rdf:rdf/sbol:componentdefinition[sbol:component/sbol:component]/@rdf:about = .]]", nsResolver);
    if ($components.length == 0)
    {
        $components = $xml.xpath("/rdf:rdf/sbol:componentdefinition[sbol:component/sbol:component]", nsResolver);
    }
    $components.each(function () {
         
        $($(this).children()).each(function () {
            if (this.tagName == "dcterms:title") {
                markup += "device:" + this.textContent + "\n{\n";
            }else
                if(this.tagName=="sbol:component")
                {
                    $($($(this).children()).children()).each(function () {
                        if (this.tagName == "sbol:definition") {
                            compdefinition = this.attributes[0].value;
                            $compdef = $xml.xpath('/rdf:rdf/sbol:componentdefinition[@rdf:about="' + compdefinition + '"]', nsResolver);
                            $compdef.each(function () {
                                var op, dir, desc
                                $($(this).children()).each(function () {
                                    /*if (this.tagName == "dcterms:title") {
                                        desc = this.textContent;
                                    }
                                    else*/
                                    if (this.tagName == "sbol:displayid") {
                                        desc = this.textContent;
                                    }
                                    else
                                        if (this.tagName == "sbol:role") {
                                            op = SOmap["SO" + this.attributes[0].value.split("so:")[1]] != null ? SOmap["SO" + this.attributes[0].value.split("so:")[1]] : "ud";
                                        }
                                })
                                markup += op + "(" + desc + ",>,black)\n";
                            })
                        }
                    })
                }
        })
        markup += "}\n";
    })
    return markup;
}
function drawSVG(markup)
{
    buildNodesfromMarkup(markup);
    svg.selectAll("g").remove();
    var genter = svg.selectAll("g")
      .data(nodes).enter().append("g")
    genter.append("svg:path")
    .attr("d", function(d) { return flow_shapes[d.NodeType](d.from,d.to);})
    .attr("stroke",function (d) { return d.color })
    .attr("fill", "none")
    .attr("transform", function (d) {
        if (d.NodeType != 'bod') {
            if (eval(d.rev) == false)
                return "translate(" + d.x + "," + d.y + ") scale(" + scale + ")"
            else
                return "translate(" + d.x + "," + d.y + ")  scale(" + scale + ") rotate(180," + 25 + "," + 50 + ")"
        }
        else return ""
    });
    var text = genter.append("svg:text")
    var textLabels = text
      .attr("x", function (d) { return eval(d.x) +  10 * scale; })
      .attr("y", function (d) {
          if (d.NodeType != 'bod')
              return eval(d.y) + (eval(d.id) % 2) * 10;
          else
              return eval(d.y) - 60;
      })
      .text(function (d) { return d.desc; })
      .attr("font-family", "sans-serif")
      .attr("font-size", eval(16*scale) + "px")
      .attr("fill", function (d) { return d.color; })
    ;

    genter.append("svg:path")
    .attr("d", function (d) { return flow_base[d.NodeType](); })
    .attr("stroke", "black")
    .attr("fill", "none")
    .attr("transform", function (d) {
        return "translate(" + d.x + "," + d.y + ") scale(" + scale + ")"
        //return "translate(" + d.x + "," + d.y + ") rotate(180," + 25 + "," + 50 + ")"
    });

    /*svg.select("path")
      .data(regulations).enter().append("svg:path")
      .attr("d", function (d) { return reg_shapes[d.RegType](); })
      .attr("stroke", function (d) { return d.color })
      .attr("fill", "none");
    */
    var svg1 = document.querySelector("svg");
    var bbox = svg1.getBBox();
    //svg1.setAttribute("viewBox", [bbox.x, bbox.y, bbox.width, bbox.height]);
    svg1.width.baseVal.valueAsString = bbox.width +200;
    svg1.height.baseVal.valueAsString = bbox.height + 100;
}
function InitSVG(){
    svg = d3.select("#dvSvg").append("svg:svg").attr("width", "600").attr("height", "600").style("stroke-width", "2").style("stroke-linecap", "round").style("stroke-linejoin", "round").style("overflow", "visible")
}

